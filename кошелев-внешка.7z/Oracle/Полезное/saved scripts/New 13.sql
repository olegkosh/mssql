alter session set tracefile_identifier=TEST_PROXY_TEST events '10046 trace name context forever, level 12';


CREATE OR REPLACE FUNCTION TEST_PROXY.FUNTEST RETURN NUMBER IS
BEGIN
   WHILE TRUE LOOP NULL;
   END LOOP;
   RETURN 2;
END funtest;
/
