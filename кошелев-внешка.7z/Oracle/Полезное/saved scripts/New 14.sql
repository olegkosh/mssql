select a.ksppinm name, b.ksppstvl value, b.ksppstdf deflt, 
       decode (a.ksppity, 1,'boolean',2,'string',3,'number',4,'file',a.ksppity) type,
       DECODE (BITAND (ksppiflg / 256, 1), 1, 'TRUE', 'FALSE') isses_modifiable,
       DECODE (BITAND (ksppiflg / 65536, 3),
               1, 'IMMEDIATE',
               2, 'DEFERRED',
               3, 'IMMEDIATE',
               'FALSE') issys_modifiable,
       DECODE (BITAND (ksppiflg / 524288, 1), 1, 'TRUE', 'FALSE') ispdb_modifiable,
       DECODE (BITAND (ksppiflg, 4), 
               4, 'FALSE',
               DECODE (BITAND (ksppiflg / 65536, 3), 0, 'FALSE', 'TRUE')) isinstance_modifiable,
       DECODE (BITAND (ksppstvf, 7),
               1, 'MODIFIED',
               4, 'SYSTEM_MOD',
               'FALSE') ismodified,
       DECODE (BITAND (ksppstvf, 2), 2, 'TRUE', 'FALSE') isadjusted,
       DECODE (BITAND (ksppilrmflg / 64, 1), 1, 'TRUE', 'FALSE') isdeprecated,
       a.ksppdesc description 
       from sys.x$ksppi a, sys.x$ksppcv b 
       where a.indx=b.indx
         and a.ksppinm like '\_bct%' escape '\'
       order by name;
       
       
       
select * from V$FIXED_TABLE       
