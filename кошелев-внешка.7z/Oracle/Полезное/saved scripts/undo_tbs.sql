select sum(a.bytes)/1024/1024/1024 as "UNDO_SIZE_IN_GB"

select a.* --a.bytes, a.name
from v$datafile a, v$tablespace b, dba_tablespaces c 
where c.contents = 'UNDO'
and c.status = 'ONLINE'
--and c.tablespace_name = 'UDNO11'
and b.name = c.tablespace_name
and a.ts# = b.ts#;

KO_COOP_ESTIMATE_CALC

select * from dba_tablespaces where contents = 'UNDO';
select * from v$datafile where 

'1bu5xpjqs4kzf'