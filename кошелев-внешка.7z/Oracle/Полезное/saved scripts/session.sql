

select * from dba_objects where data_object_id=18319457;

--- �������� ��� ��������� ddl �������
select * from v$session a where SID in (
select session_ID from dba_ddl_locks where name = upper ('ORGANIZATION_REGISTER_115_CALC') order by session_ID;
) 
and status ='ACTIVE'

SELECT COUNT(*) FROM V$LOCKED_OBJECT LO
INNER JOIN DBA_OBJECTS O ON 
O.OBJECT_ID = LO.OBJECT_ID
WHERE O.OBJECT_NAME = 'IDWH2_MR_MASTER_FUZZY_SEARCH' AND
O.OWNER = 'BAIKAL';





select object_name, a.sid, a.serial#
from v$session a, v$locked_object b, dba_objects c
where 
b.OBJECT_ID=c.OBJECT_ID
and a.sid=b.SESSION_ID
order by object_name;

--- ����� ������ 
alter system kill session '7868,14313';

--- ��� ���������� ������� ������
select  s.username,
        s.sid,
        s.serial#,
        t.used_ublk,
        t.used_urec,
        r.rssize,
        r.status
from    v$transaction t,
        v$session s,
        v$rollstat r,
        dba_rollback_segs rs
where   s.saddr=t.ses_addr
    and t.xidusn=r.usn
    and rs.segment_id=t.xidusn
order by t.used_ublk desc;











select count(*),event,blocking_session,blocking_session_serial# 
from dba_hist_active_sess_history 
where sample_time between timestamp'2022-02-04 2:0:0' and timestamp'2022-02-04 5:0:0' and program ='Server.exe'
group by event,blocking_session,blocking_session_serial# order by 1 desc 

select count(*),event
from dba_hist_active_sess_history 
where sample_time between timestamp'2022-02-07 2:0:0' and timestamp'2022-02-07 5:0:0' and program ='Server.exe'
group by event order by 1 desc 





exec dbms_scheduler.set_attribute('IDWH2.DMZ_SYNC_141','max_run_duration',numtodsinterval(1, 'HOUR'))

select count(*),event from v$session where program ='Server.exe' and wait_class<>'Idle' group by event


select count(*),event from v$active_session_history where program='Server.exe' group by event order by 1 desc

select * from v$session where sid in(
select blocking_session from v$session where event='cursor: pin S wait on X')


��� ���������� �� ������ ������ ������� ������ ������� ������� SYSTEM.GRANT_COMPILE_TRIGGER � SYSTEM.REVOKE_COMPILE_TRIGGER


select * from v$session where event='cursor: pin S wait on X'

select * from v$sgastat where name like 'CTWR%'



select * from v$sql where sql_id='8gaysqd6r8yxp'

select * from dba_sql_plan_baselines where sql_handle='SQL_4646ac8955e94e6e' plan_name='SQL_PLAN_4cjpcj5aykmmf7556a0ec'

declare
n number;
begin
 n := sys.dbms_spm.drop_sql_plan_baseline('SQL_4646ac8955e94e6e');
end;




select * from dba_hist_sqlstat where sql_id='8gaysqd6r8yxp'			








