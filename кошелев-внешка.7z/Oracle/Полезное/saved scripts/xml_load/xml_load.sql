DECLARE
xml_file BFILE;
xml_data CLOB;
xml_file_name VARCHAR2(2000 BYTE);

BEGIN
xml_file_name := 'CRB_�1_FL_26.04.2022.xml';
xml_file := BFILENAME ('DATA_PUMP_DIR', xml_file_name);
DBMS_LOB.createtemporary (xml_data, TRUE, DBMS_LOB.SESSION);
DBMS_LOB.fileopen (xml_file, DBMS_LOB.file_readonly);
DBMS_LOB.loadfromfile (xml_data, xml_file, DBMS_LOB.getlength (xml_file));
DBMS_LOB.fileclose (xml_file);
-----
insert into baikal.oper_territor_load (id_file, file_name, file_data, 
--source_id, actual_date, create_date,
status)
values (8,xml_file_name, xml_data,0);

--DBMS_OUTPUT.PUT_LINE (SQL%ROWCOUNT || 'row inserted.');
DBMS_LOB.freetemporary (xml_data);
-----
commit;
END;