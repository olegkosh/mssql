DECLARE
l_clob CLOB;
l_bfile bfile;
l_dest_offset   integer :=1;
l_source_offset integer :=1;
l_dbile_csid    number  :=0;
l_lang_context  integer :=0;
l_warning       integer :=0;
--
l_file_name VARCHAR2(2000 BYTE);


BEGIN
 l_file_name := 'CRB_�1_FL_26.04.2022.xml';
 

 --insert into  XXXX (id,clob_data)
   -- values (1, empty_clob())
   -- return clob_data into l_clob;
    
    -----
 insert into baikal.oper_territor_load (id_file, file_name, file_data, 
--source_id, actual_date, create_date,
    status)
    values (8,l_file_name, empty_clob(),0)
    return file_data into l_clob;
 

 
 l_bfile:=bfilename ('DATA_PUMP_DIR', l_file_name);
 DBMS_LOB.fileopen (l_bfile, DBMS_LOB.file_readonly);
 DBMS_LOB.loadclobfromfile (
    dest_lob        =>  l_clob,
    source_bfile    =>  l_bfile,
    amount          =>  DBMS_LOB.lobmaxsize,
    dest_offset     =>  l_dest_offset,
    source_offset   =>  l_source_offset,
    dbile_csid      =>  l_dbile_csid,
    lang_context    =>  l_lang_context,
    warning         =>  l_warning);
 DBMS_LOB.fileclose (l_bfile); 
 
 commit;   
 
 
END;



















l_file utl_file.file_type;
l_data CLOB;
l_file_name VARCHAR2(2000 BYTE);
l_dir_name VARCHAR2(2000 BYTE);
l_buffer VARCHAR2(4096);

BEGIN
xml_file_name := 'CRB_�1_FL_26.04.2022.xml';
--l_dir_name:='/ora_mix/dmp'
l_file := utl_file.fopen ('DATA_PUMP_DIR', xml_file_name,'R');
DBMS_LOB.createtemporary (l_data, TRUE, DBMS_LOB.CALL);
LOOP
 BEGIN
  utl_file.get_line (l_file, l_buffer);
  dbms_output.put_line(l_buffer);
  dbms_lob.writeappend (l_data, length (l_buffer), l_buffer);
  
  EXCEPTION
   WHEN no_data_found THEN
    









DBMS_LOB.createtemporary (xml_data, TRUE, DBMS_LOB.SESSION);
DBMS_LOB.fileopen (xml_file, DBMS_LOB.file_readonly);
DBMS_LOB.loadfromfile (xml_data, xml_file, DBMS_LOB.getlength (xml_file));
DBMS_LOB.fileclose (xml_file);
-----
insert into baikal.oper_territor_load (id_file, file_name, file_data, 
--source_id, actual_date, create_date,
status)
values (8,xml_file_name, xml_data,0);

--DBMS_OUTPUT.PUT_LINE (SQL%ROWCOUNT || 'row inserted.');
DBMS_LOB.freetemporary (xml_data);
-----
commit;
END;