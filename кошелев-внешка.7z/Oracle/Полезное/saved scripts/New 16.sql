-- ��������� ������
define d1 = date'2022-2-4';
define d2 = date'2022-2-11';

select t.ts_list,t.cnt,f.fnames from 
(with t as (
            select case row_number() over (partition by tablespace_name order by 1) 
                    when 1 then tablespace_name 
                   end tablespace_name, 
                   count(*) over () cnt,
                   name
             from v$datafile,
                  dba_data_files 
                  where file_id=file# and creation_time between &&d1  and &&d2
           ) 
select listagg(t.tablespace_name,', ') within group (order by t.tablespace_name) ts_list, avg(cnt) cnt
from t) t,
(select 
trunc(v.creation_time) cr_time,
-- listagg(d.tablespace_name,', ') within group (order by rownum) tsname,
listagg(name,', ') within group (order by rownum)||' ('||trunc(creation_time)||')' fnames
from v$datafile v, dba_data_files d
where file_id=file# and 
creation_time between &&d1  and &&d2
group by trunc(v.creation_time)) f
order by f.cr_time;


select * from dba_objects where data_object_id=18319457


select * from dba_ddl_locks where name='IMAGE_DESTIN_DMZ'


alter index baikal.IX_IMAGE_DESTIN_DMZ_4 rebuild;

SYS_IL0016951541C00005$$

select count(*),event,blocking_session,blocking_session_serial# 
from dba_hist_active_sess_history 
where sample_time between timestamp'2022-02-04 2:0:0' and timestamp'2022-02-04 5:0:0' and program ='Server.exe'
group by event,blocking_session,blocking_session_serial# order by 1 desc 

select count(*),event
from dba_hist_active_sess_history 
where sample_time between timestamp'2022-02-07 2:0:0' and timestamp'2022-02-07 5:0:0' and program ='Server.exe'
group by event order by 1 desc 

enq: CT - CTWR process start/stop



exec dbms_scheduler.set_attribute('IDWH2.DMZ_SYNC_141','max_run_duration',numtodsinterval(1, 'HOUR'))

select count(*),event from v$session where program ='Server.exe' and wait_class<>'Idle' group by event


select count(*),event from v$active_session_history where program='Server.exe' group by event order by 1 desc

select * from v$session where sid in(
select blocking_session from v$session where event='cursor: pin S wait on X')


��� ���������� �� ������ ������ ������� ������ ������� ������� SYSTEM.GRANT_COMPILE_TRIGGER � SYSTEM.REVOKE_COMPILE_TRIGGER


select * from v$session where event='cursor: pin S wait on X'

select * from v$sgastat where name like 'CTWR%'

select * from dba_audit_trail where timestamp between timestamp'2022-02-07 3:25:0' and timestamp'2022-02-07 3:32:0' and action=100 and returncode <>0



insert into baikal.pak_oa_person_sign 
(id_sign_type, 
 etalon_registry_id,
 sign_code, 
 calc_date) 
select v.id_sign_type,
       v.etalon_registry_id,
       'SS349', --��� ��������
       sysdate
from
(select distinct m.etalon_registry_id, 941397188 id_sign_type --�� ��������
from baikal.org_group_link ogl
          inner join idwh2.idw_mr_master m
          on m.etalon_registry_id = ogl.etalon_registry_id
where  ogl.id_org_group in (23765, 23771, 23772) and ogl.etalon_registry_id is not null --�� ������ ���������
and not exists (select ETALON_REGISTRY_ID from baikal.pak_oa_person_sign where id_sign_type = 941397188 and --�� ��������
ETALON_REGISTRY_ID=ogl.etalon_registry_id)) v;
commit;

5 rows created.
Commit complete.

insert into baikal.pak_oa_person_sign 
(id_sign_type, 
 etalon_registry_id,
 sign_code, 
 calc_date) 
select v.id_sign_type,
       v.etalon_registry_id,
       'SS850', --- ��� �������� ���
       sysdate
from
(select distinct m.etalon_registry_id, 941398747 id_sign_type --- id_�������� ���
from baikal.org_group_link ogl
          inner join idwh2.idw_mr_master m
             on m.etalon_registry_id = ogl.etalon_registry_id
where  ogl.id_org_group in (23762, 23763, 23768, 23769) and ogl.etalon_registry_id is not null --- id_������ (��� ������� ���������)
and not exists (select ETALON_REGISTRY_ID from baikal.pak_oa_person_sign where id_sign_type=941398747 and ETALON_REGISTRY_ID=ogl.etalon_registry_id)) v;  -- id_�������� ���
commit;

690 inserted
_____________________________________
�� ����� ���������: 23762, 23763, 23768, 23769




SELECT 
			FP.ID_FILE_PACKAGE,
            FX.FILE_DATA, fx.rowid ri
		FROM
            BAIKAL.FILE_PACKAGE_COMMON C
                INNER JOIN BAIKAL.FILE_PACKAGE FP ON
                    C.ID_FILE_PACKAGE = FP.ID_FILE_PACKAGE AND
                    FP.ID_FILE_PACKAGE_STATUS = 9 /*������ � ������� ������� ������������*/
				INNER JOIN BAIKAL."FILE" FX ON
					FP.ID_FILE_ZIP = FX.ID_FILE
		WHERE
			C.ID_FILE_PACKAGE_STATUS = 9;
			
			update BAIKAL."FILE" FX set FILE_DATA=null where rowid='AEUlN+AErAACUkZAAX'
			
			select * from  BAIKAL."FILE" where rowid='AEUlN+AErAACUkZAAX'			
			
select * from v$sql where sql_id='8gaysqd6r8yxp'

select * from dba_sql_plan_baselines where sql_handle='SQL_4646ac8955e94e6e' plan_name='SQL_PLAN_4cjpcj5aykmmf7556a0ec'

declare
n number;
begin
 n := sys.dbms_spm.drop_sql_plan_baseline('SQL_4646ac8955e94e6e');
end;




SYS_SQLPROF_017ee958d7eb0001
select * from dba_hist_sqlstat where sql_id='8gaysqd6r8yxp'			



LINK_SUBJ_EOR_WITH_OR





select count(1)
  from idwh2.idw_sy_workflow_info l
  where workflow_id = 261 and state_id = 2611;
  
  
  
select count(1)
from idwh2.idwh2_load l
where type_data_id = 2069
    and type_load_id = 4
    and not exists (select 1
                    from idwh2.idw_sy_workflow_error err
                    where err.workflow_id = 169
                        and err.state_id = 1691
                        and err.object_id = to_char(l.load_id)
                   );
                   
                   
                   
EOR_SPM_VIOLATION_LOAD