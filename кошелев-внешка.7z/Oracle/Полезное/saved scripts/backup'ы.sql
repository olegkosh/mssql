SELECT SESSION_KEY, INPUT_TYPE, STATUS, to_char(START_TIME,'mm/dd/yy hh24:mi') 
start_time,
to_char(END_TIME,'mm/dd/yy hh24:mi')
end_time,
output_bytes_display "SIZE",
time_taken_display "TIME",
output_device_type from V$RMAN_BACKUP_JOB_DETAILS
order by session_key desc;
