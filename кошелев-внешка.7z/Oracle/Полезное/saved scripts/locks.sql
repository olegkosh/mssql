select *
from v$lock
where SID in (11436);
select * from v$session where sid in (
select session_id from dba_ddl_locks
 where name like '%operation_violtation_time'
);



select *
from v$lock
where 
--ID1 in (select id1 from v$lock where SID in (11436))
--or
 ID2 in (select id1 from v$lock where SID in (11436) );

1442352


select * from v$session where serial#=(
select serial# from v$session where sid= 
(select *
from v$lock
where id1 in (
select object_id
--, object_name 
from all_objects where object_name like 'KO_COOP%')
));


select * from v$session where sid in (
select session_id from dba_ddl_locks where name='KO_COOP_ESTIMATE_CALC'
);

--����������
SELECT *
--, sid AS "���� �������������(SID)", blocking_session as "� �������� ������ �������(SID)", username, event 
FROM V$SESSION WHERE --blocking_session_status = 'VALID' and 
(sid=11436 or blocking_session=11436);

select sid, module, action, program, status, osuser, machine, event, logon_time FROM V$SESSION
where sid in (SELECT blocking_session FROM V$SESSION WHERE blocking_session_status = 'VALID')
union all
select sid, module, action, program, status, osuser, machine, event, logon_time FROM V$SESSION
where sid in (SELECT sid FROM V$SESSION WHERE blocking_session_status = 'VALID');

select ' ' as Status,
       s1.sid, 
       s1.USERNAME,
       s1.LOGON_TIME,
--       s1.SERIAL#, 
       s1.status, 
       s1.PROGRAM, 
       s1.module, 
       s1.ACTION, 
       s1.BLOCKING_SESSION ,
       S1.SQL_ID,
       S1.EVENT
       from v$session s1 where s1.BLOCKING_INSTANCE is not Null
union all

select distinct
       '����������� ������' as Status,
       s2.sid, 
       s2.USERNAME,
       s2.LOGON_TIME,
 --      s2.SERIAL#, 
       s2.status, 
       s2.PROGRAM, 
       s2.module, 
       s2.ACTION, 
       s2.BLOCKING_SESSION , 
       S2.SQL_ID,
       S2.EVENT
       from v$session s2 where SID in (select BLOCKING_SESSION from v$session  where BLOCKING_INSTANCE is not Null) and s2.BLOCKING_INSTANCE is Null
  --     and (SID=11436 OR BLOCKING_SESSION=11436)
order by  blocking_session, username, sid;


















select 
'begin
   CTXSYS.CTX_DDL.SYNC_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',PART_NAME =>'''||partition_name||''',parallel_degree=>16);
   CTXSYS.CTX_DDL.OPTIMIZE_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',''FULL'',PART_NAME =>'''||partition_name||''',parallel_degree=>16);
   commit;
end;' 
from dba_ind_partitions where index_name='IDX_ESI_NAME_4_3';

select 'exec CTXSYS.CTX_DDL.OPTIMIZE_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',''FULL'',PART_NAME =>'''||partition_name||''',parallel_degree=>16)'||CHR(10)||'commit;' 
from dba_ind_partitions where index_name='IDX_ESI_NAME_4_3';

begin
execute immediate
'begin
   CTXSYS.CTX_DDL.SYNC_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',PART_NAME =>''P0'',parallel_degree=>16);
   CTXSYS.CTX_DDL.OPTIMIZE_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',''FULL'',PART_NAME =>''P0'',parallel_degree=>16);
   commit;
end;' ;
end;



declare
  return_code number;
  duration_threshold number := 1/6;
  
begin
  for cursr in
    ( select 
    'begin
   CTXSYS.CTX_DDL.SYNC_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',PART_NAME =>'''||partition_name||''',parallel_degree=>16);
   CTXSYS.CTX_DDL.OPTIMIZE_INDEX(''IDWH2.IDX_ESI_NAME_4_3'',''FULL'',PART_NAME =>'''||partition_name||''',parallel_degree=>16);
   commit;
   exception
     when others then system.track_short;
     raise;
    end;' plsqlblock 
    from dba_ind_partitions where index_name='IDX_ESI_NAME_4_3';)
  loop 
    execute immediate cursr.plsqlblock;
  end loop;
END;


select count(*),count(distinct sql_exec_id), min(sample_time), max(sample_time), sql_id,session_id 
from v$active_session_history where session_id=10172 --and session_id=10507 and sample_time > sysdate - 5.5 --and sql_id='atrf8xc1y79nh'
group by sql_id,session_id order by 1 desc



select count(*),count(distinct sql_exec_id),sql_id from v$active_session_history where session_id=8494 group by sql_id  order by 1 desc

select * from v$sql where sql_id='0up9p8wc80q0j'

select * from SYS.V_$SESS_TIME_MODEL where sid=8494


select * from track_detail where track_time between timestamp'2021-12-30 18:20:03.0' and timestamp'2021-12-30 18:22:55.0' 

select sysdate, wwwapp.pkgDN_Context.fnGet('PARTMINDOCS')
from dual;

select * from v$sql where sql_id in ('csns2948yx91g')

select * from dba_sql_plan_baselines where signature in(
select distinct force_matching_signature from dba_hist_sqlstat where sql_id in ('csns2948yx91g'))

select * from dba_data_files
idwh2_tbs
select *from dba_hist_sqlstat where sql_id in ('csns2948yx91g')

 select NAME from v$datafile where FILE#                                              =1845;

ASDM_J

select end_interval_time, h.* from dba_hist_sqlstat h,sn where sn.snap_id=h.snap_id and sql_id in ('csns2948yx91g') order by 1 

create index EOR.IX_SR_SUBJECT$1 on EOR.SR_SUBJECT("SR_TYPE_ID","EXCL_DATE","DELETED_SIGN") tablespace eor_index_tbs;
create index IDWH2.IDX$$_4CE140001 on IDWH2.IDW_MR_SUBJECT_MENTION("EOR_SUBJECT_MENTION_ID","MENTION_ATTRIBUTE_ID","EOR_MENTION_TYPE_ID");

select rowid, dda_tbl.* from dda_tbl
select * from dba_hist_active_sess_history where sample_time between sysdate  - 7 and sysdate - 1 and sql_id in ('cfqc32fmw0yad','bytsrrqcku2m0') 


select end_interval_time, h.* from dba_hist_sqlstat h,sn where sn.snap_id=h.snap_id and sql_id in ('cfqc32fmw0yad','bytsrrqcku2m0') order by 1 



select * from v$sql where  sql_id in ('cfqc32fmw0yad','bytsrrqcku2m0')

select * from dba_scheduler_job_run_details where log_date > sysdate - 3 and job_name like 'PAK_%' order by log_date desc

select distinct MESSAGE_TYPE_ID from IDWH2.IDW_OA_OPERATION_MESSAGE where MESSAGE_TYPE_ID not in (173,174) order by 1
select distinct MESSAGE_TYPE_ID from IDWH2.IDW_OA_OPERATION_MESSAGE where MESSAGE_TYPE_ID <173 or MESSAGE_TYPE_ID >174order by 1
 OM LEFT JOIN
             IDWH2.IDW_DR_OPERATION_KIND OK ON OK.ID = OM.OPERATION_KIND_ID
             WHERE OM.ID_DM = :B1 AND OM.MESSAGE_TYPE_ID NOT IN (173,174)