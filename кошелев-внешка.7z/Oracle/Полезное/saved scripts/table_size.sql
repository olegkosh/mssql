Select count (*) From BAIKAL.PAK_OA_SIGN_LOG;
Select distinct user_name From BAIKAL.PAK_OA_SIGN_LOG where rownum < 2001; last_value


11869520433
11869520444
11869520450

--truncate table BAIKAL.PAK_OA_SIGN_LOG;



S
select sum(bytes)/1024/1024/1024 as s, owner from dba_segments group by owner order by s;
select segment_name,  segment_type, owner , sum(bytes)/1024/1024/1024 as s from dba_segments 
--where owner ='IDWH2' 
group by segment_name, segment_type, owner order by s desc;;