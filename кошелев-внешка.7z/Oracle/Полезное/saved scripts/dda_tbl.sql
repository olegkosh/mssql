select * from dda_tbl
where username = 'paliy' or 
      os_user like '%palijol%' or
      ip_address='10.10.145.141' or
      rule_comment like '%�����%'
     