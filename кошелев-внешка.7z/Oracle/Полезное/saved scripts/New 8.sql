IDW_ARJ_MSG_443_1

select count(*),event from v$session where wait_class<>'Idle' group by event order by 1 desc
select * from v$session where sid in (select sid from v$access where object='PKG_EOR_AUX')
select s1.*,s2.* from 
(select final_blocking_session,event,count(*) 
from v$session  
where final_blocking_session is not null and event not like 'PX Deq%' 
group by final_blocking_session,event) s1,
v$session s2 where s2.sid=s1.final_blocking_session
order by 3 desc

select s.*, s2.* from v$session s2, 
(select s1.event,s1.final_blocking_session , count(*) c from v$session s1 
where s1.final_blocking_session is not null and  s1.event not like '%PX%' and s1.event not in('read by other session', 'enq: UL - contention')
 group by s1.event,s1.final_blocking_session) s where  s.final_blocking_session=s2.sid 
 order by s.c desc ;

select * from v$session where event like  'library cache lock'

EOR_RUL_DOUBLE_IDENT
select * from v$database

select * from v$sql where sql_id='2wyyx0gm86j1f'

select * from dba_sql_plan_baselines where  sql_handle='SQL_183e4df17668380a' plan_name='SQL_PLAN_1hgkdy5v6hf0a6c6e0105'
select * from v$session where program like 'rman%' SCHEMANAME='SYS' action like '%RMAN%'

select * from V$session_longops where opname = 'RMAN: aggregate input';

SELECT COUNT(1) 
FROM EOR.IDW_MR_SUBJ_ADDRESS_MENTION ADDR_M 
INNER JOIN EOR.IDW_MR_ADDRESS_MENTION AM ON AM.EOR_ADDRESS_MENTION_ID = ADDR_M.EOR_ADDRESS_MENTION_ID 
INNER JOIN IDWH2.IDW_SY_WORKFLOW_INFO WI ON WI.WORKFLOW_ID = 11 AND WI.OBJECT_ID = TO_CHAR(AM.EOR_ADDRESS_MENTION_ID) 
WHERE ADDR_M.EOR_SUBJECT_MENTION_ID = :B1 AND NVL(AM.EOR_ADDRESS_ID, 0) = 0 AND WI.ERROR_SIGN <> '?'
 


select a.ksppinm name, b.ksppstvl value, b.ksppstdf deflt,
       decode (a.ksppity, 1,'boolean',2,'string',3,'number',4,'file',a.ksppity) type,
       a.ksppdesc description, a.*, b.* 
       from sys.x_$ksppi a, sys.x_$ksppcv b 
       where a.indx=b.indx
         and a.ksppinm like '\_kgl_large%' escape '\' 
       order by name

select p1.parameter_name,p1.value,p2.value 
from SYS.DBA_HIST_PARAMETER p1, SYS.DBA_HIST_PARAMETER p2
where p1.snap_id=102809 and p2.snap_id=103474 and p1.parameter_hash=p2.parameter_hash and p1.value <> p2.value  

EVENT
cursor: pin S wait on X
cursor: mutex S

select * from v$session where 

PAK_FOREXIS_J

select * from dba_scheduler_job_run_details where job_name in('KSAND_ORG_MARK_CALC') order by 1 desc

select * from v$session where sid in (
select session_id from dba_ddl_locks where name='LOAD_MSG_UTILS')

select * from v$sql  where sql_id in ('5ph71zu497b7p','fbwsdpktjbf80', '8ph4rc8t02uc8') 8ph4rc8t02uc8


SELECT * 
FROM DBA_SCHEDULER_JOB_RUN_DETAILS
WHERE job_name = 'NORM_110_5'
 and log_id in (352344146,352340556,352336860)


SELECT * 
FROM DBA_SCHEDULER_JOB_RUN_DETAILS
WHERE job_name in( 'TASK$_13026638_5', 'TASK$_13026728_1', 'TASK$_13026566_1') 

select * from v$instance