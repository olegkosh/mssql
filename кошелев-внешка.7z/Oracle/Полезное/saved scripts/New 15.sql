DMZ_SYNC_141

select * from v$sgastat where name like '%strand%'

select * from v$latch_children where name='redo allocation';

select a.ksppinm name, b.ksppstvl value, b.ksppstdf deflt, 
       decode (a.ksppity, 1,'boolean',2,'string',3,'number',4,'file',a.ksppity) type,
       DECODE (BITAND (ksppiflg / 256, 1), 1, 'TRUE', 'FALSE') isses_modifiable,
       DECODE (BITAND (ksppiflg / 65536, 3),
               1, 'IMMEDIATE',
               2, 'DEFERRED',
               3, 'IMMEDIATE',
               'FALSE') issys_modifiable,
       DECODE (BITAND (ksppiflg / 524288, 1), 1, 'TRUE', 'FALSE') ispdb_modifiable,
       DECODE (BITAND (ksppiflg, 4), 
               4, 'FALSE',
               DECODE (BITAND (ksppiflg / 65536, 3), 0, 'FALSE', 'TRUE')) isinstance_modifiable,
       DECODE (BITAND (ksppstvf, 7),
               1, 'MODIFIED',
               4, 'SYSTEM_MOD',
               'FALSE') ismodified,
       DECODE (BITAND (ksppstvf, 2), 2, 'TRUE', 'FALSE') isadjusted,
       DECODE (BITAND (ksppilrmflg / 64, 1), 1, 'TRUE', 'FALSE') isdeprecated,
       a.ksppdesc description 
       from sys.x_$ksppi a, sys.x_$ksppcv b 
       where a.indx=b.indx
         and a.ksppinm like '\_bct%' escape '\'
       order by name;

select to_char(delta/1024/1024/1024,'99.99') delta_gb,t.name ts_name, o.* from dba_objects o, v$tablespace t, 
(select * from 
  (select sum(space_allocated_delta) delta,dataobj#,ts# from sys.wrh$_seg_stat 
    where snap_id >= (select snap_id from DBA_HIST_SNAPSHOT where (sysdate -1) between begin_interval_time and end_interval_time )  -- 7 - ������
    group by dataobj#,ts# order by sum(space_allocated_delta) desc) 
where rownum<1000) s  -- 1000 ������ 
where data_object_id=dataobj# and s.ts#=t.ts# and name ='IDWH2_TBS'
 order by delta desc;

select * from v$sql where sql_id='87hyjfnj62xsw'
select * from dba_scheduler_job_run_details where job_name like 'PAK_CONT%' order by 1 desc
PAK_OA_SIGN_VALUE

select sys_context('USERENV','CLIENT_PROGRAM_NAME') from dual;


IDW_OA_OPER_ATTR

BAIKAL.PAK_OA_SIGN_VALUE
USER_ID
3617,4352,5713

select count(*),sql_id,event,user_id from v$active_session_history where user_id in (3617,5713) group by sql_id,event,user_id order by 1 desc 
select * from v$active_session_history where user_id in (3617,5713) and event='enq: TX - row lock contention'

LG_TR

select * from dba_objects where object_id in (2333404, 2333381)
OFFENSE_CASE
select * from v$active_session_history where (session_id,session_serial#) in ((10472,	47066))

GRANT ALTER ANY TRIGGER, ADMINISTER DATABASE TRIGGER TO IDWH2;

grant ALTER ANY TRIGGER to idwh2;

grant ADMINISTER DATABASE TRIGGER to test_proxy

REVOKE ALTER ANY TRIGGER,ADMINISTER DATABASE TRIGGER FROM IDWH2;
disk_free_hist
select * from track_detail where error_stack  like '%ORA-04045%' and track_time  > sysdate -2

revoke ALTER ANY TRIGGER from idwh2;

select * from dba_sys_privs where privilege in ('ALTER ANY TRIGGER','ADMINISTER DATABASE TRIGGER')
idwh2

select * from 

USER_ID	SQL_ID
3716	703cqmfybr8a6

2333404

KOFR_FIGURE_PROFILE_JOB

select * from dba_users where username like 'LUK%' or username like 'DFO_SAL%'
USERNAME
SAMUYLOVA_OA

select COUNT(1) as REG_NUM_CNT
from BAIKAL.TERRORISTS
where REG_NUM  = OGRN--is not null --and REG_NUM <>''
      and ID_REC_STATUS =0

SELECT *
 FROM DBA_SCHEDULER_JOB_RUN_DETAILS
 WHERE
     OWNER = 'KOFR' AND
     JOB_NAME LIKE 'SCORING_OBJ_PRL%' AND
     ACTUAL_START_DATE > TRUNC(SYSDATE,'DD')


select * from dba_scheduler_job_run_details where job_name='PAK_OA_SIGN_VALUE_INS'

select * from v$sql where sql_id='akbcdguxy7s9a'

"STMTEH.PR_EXP_KOFR_REFER"

STMTEH

select length(substr ('***************************************************************************',1,30)) from dual

select * from SYS.DBA_DATAPUMP_JOBS;

select * from v$session where saddr in (select saddr from SYS.DBA_DATAPUMP_SESSIONS);

PROGRAM_ID	PROGRAM_LINE#
select * from dba_objects where object_id=2287558	4670
PAK_OPERATIONS

select * from v$sql where sql_id='87hyjfnj62xsw'

SELECT *
FROM BAIKAL.ORG_REG_115_7_1_EXT_H_V2_V

BAIKAL.ORG_REG_115_7_1_EXT_H_V2_V