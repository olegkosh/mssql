--������ ������

select owner,
       table_name,
       TRUNC (sum (bytes)/1024/1024/1024) Size_Gb
FROM
 (       
       select segment_name table_name, owner, bytes from dba_segments where segment_type in ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')

UNION ALL

select l.table_name, l.owner, s.bytes from dba_lobs l, dba_segments s where
s.segment_name=l.segment_name 
and s.owner=l.owner
and s.segment_type in ('LOB_SEGMENT','LOB PARTITION')

UNION ALL

select i.table_name, i.owner, s.bytes from dba_indexes i, dba_segments s where
s.segment_name=i.index_name 
and s.owner=i.owner
and s.segment_type in ('INDEX','INDEX PARTITION', 'INDEX SUBPARTITION') 

)
group by owner,
       table_name
       having sum (bytes)/1024/1024/1024 >= 100
order by sum (bytes) desc


;
--������ ��������� ������----------------------

select owner,
       table_name,
       TRUNC (sum (bytes)/1024/1024/1024) Size_Gb
FROM
 (       
       select segment_name table_name, owner, bytes from dba_segments where segment_type in ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')

UNION ALL

select l.table_name, l.owner, s.bytes from dba_lobs l, dba_segments s where
s.segment_name=l.segment_name 
and s.owner=l.owner
and s.segment_type in ('LOB_SEGMENT','LOB PARTITION')

UNION ALL

select i.table_name, i.owner, s.bytes from dba_indexes i, dba_segments s where
s.segment_name=i.index_name 
and s.owner=i.owner
and s.segment_type in ('INDEX','INDEX PARTITION', 'INDEX SUBPARTITION') 

)
where table_name in (
'LOG_CHANGE',
'IDWH2_ARJ_RD_03_FK',
'IDWH2_ARJ_RD_02_FK',
'IDWH2_ARJ_RD_05_FK',
'IDWH2_ARJ_RD_04_FK'
)
group by owner,
       table_name
     --  having sum (bytes)/1024/1024/1024 >= 10
order by sum (bytes) desc