select * from dba_hist_active_sess_history where user like '%DFO%';



select u.username, ash.* from V$active_session_history ash
join dba_users u on u.user_id=ash.user_id 
where 
ash.SAMPLE_TIME>'12/10/2022 0:02:41,930' 
and ash.SAMPLE_TIME<'12/10/2022 8:02:41,930'
like
 '%DFO%';;

select * from dba_users


select * from dba_scheduler_job_run_details where job_name like '%LOG_DEL%' order by log_date;

select * from dba_scheduler_job_run_details 
where 
LOG_DATE > '13/10/2022 05:00:04,711413 +03:00' 
and LOG_DATE < '13/10/2022 08:00:04,711413 +03:00'
--ACTUAL_START_DATE > '12/10/2022 00:16:04,711413 +04:00' 
--and ACTUAL_START_DATE < '12/10/2022 04:16:04,711413 +04:00' 
and RUN_DURATION > '+00 03:00:42.000000'
and RUN_DURATION < '+00 14:00:42.000000'
order by ACTUAL_START_DATE; 

SUBJECT_EOR_KSAND_IDENT

SUBJECT_OPERATION_IDENT_JOB


select * from dba_scheduler_job_run_details 
where
LOG_DATE > '12/10/2022 07:00:04,711413 +03:00' 
and LOG_DATE < '12/10/2022 08:30:04,711413 +03:00' 
--and ACTUAL_START_DATE > '11/10/2022 00:16:04,711413 +04:00' 
--and ACTUAL_START_DATE < '12/10/2022 04:16:04,711413 +04:00' 
and RUN_DURATION > '+00 04:00:42.000000'
and RUN_DURATION < '+00 14:00:42.000000'
order by ACTUAL_START_DATE; 


select * from dba_scheduler_job_run_details 
where
LOG_DATE > '13/10/2022 02:00:04,711413 +03:00' 
and LOG_DATE < '13/10/2022 08:00:04,711413 +03:00' 
--and ACTUAL_START_DATE > '11/10/2022 00:16:04,711413 +04:00' 
--and ACTUAL_START_DATE < '12/10/2022 04:16:04,711413 +04:00' 
--and RUN_DURATION > '+00 04:00:42.000000'
--and RUN_DURATION < '+00 14:00:42.000000'
order by ACTUAL_START_DATE desc; 

select * from dba_scheduler_job_run_details 
where
LOG_DATE > '12/10/2022 07:00:04,711413 +03:00' 
and LOG_DATE < '12/10/2022 08:30:04,711413 +03:00' 
--and ACTUAL_START_DATE > '11/10/2022 00:16:04,711413 +04:00' 
--and ACTUAL_START_DATE < '12/10/2022 04:16:04,711413 +04:00' 
and RUN_DURATION > '+00 04:00:42.000000'
and RUN_DURATION < '+00 14:00:42.000000'
order by ACTUAL_START_DATE; 


select * from dba_scheduler_job_run_details 
where
LOG_DATE > '13/10/2022 07:00:04,711413 +03:00' 
and LOG_DATE < '13/10/2022 08:30:04,711413 +03:00' 
--and ACTUAL_START_DATE > '11/10/2022 00:16:04,711413 +04:00' 
--and ACTUAL_START_DATE < '12/10/2022 04:16:04,711413 +04:00' 
and RUN_DURATION > '+00 04:00:42.000000'
and RUN_DURATION < '+00 14:00:42.000000'
order by ACTUAL_START_DATE; 