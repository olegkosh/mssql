select /*+ rule */
         s.*, decode(l.kgllkmod, 0, 'None', 1, 'Null', 2, 'Share', 3, 'Exclusive', 'Unknown') mode_held, l.kgllktype lock_or_pin

        from  v$db_object_cache o, dba_kgllock l, v$session s
        where l.kgllkmod not in (0,1)
         and l.kgllkuse = s.saddr
         and l.kgllkhdl = o.addr
         and o.owner = 'TEST_PROXY'
         and o.name = 'FUNTEST'
         and o.type = 'FUNCTION';
         
ASDM_J
         
         KSAND_ORG_MARK_SEND_MESSAGE
         
select * from sn         
131588
130845
         
select sum(TABLESPACE_USEDSIZE)*8/1024/1024/1024 from DBA_HIST_TBSPC_SPACE_USAGE where snap_id=131588   

select (65.3 - 62.7),

(61.4 - 58.1) from  dual

      LG_TR
      
      
select count(*),min(date_time),max(date_time),username,program,machine 
from system.users_audit where username in (--'BAIKAL','WWWAPP',
'EOR','EOL',
'KOFR','IDWH2_DM','IPOL') and date_time > sysdate - 700 
and machine not in( 'FEDSFM\WS455','WS455','FEDSFM\CA-NETBACKUP','ANALITIC\CA-ONIVANCHUK')
group by username,program,machine order by 1 desc

GRANT ADMINISTER DATABASE TRIGGER TO KOFR, IPOL, EOL, IDWH2_DM;


SELECT M.ID_MEASURE, M.ID_MEASURE_TYPE, M.ID_SPECIAL_NOTE, M.MEASURE_NOTE
 FROM KOFR.MEASURE M
 WHERE M.ID_MEASURE_TYPE IN
 (466624,     
 428603,
 426527,
 423161,
 463362,
 446040,
 466629,
 466634,
 466626)
 AND M.ID_REC_STATUS = 0      