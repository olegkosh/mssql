select count(*),count(distinct sql_exec_id), min(sample_time), max(sample_time), sql_id,session_id 
from v$active_session_history where session_id=8584 --and session_id=10507 and sample_time > sysdate - 5.5 --and sql_id='atrf8xc1y79nh'
group by sql_id,session_id order by 1 desc



select count(*),count(distinct sql_exec_id), min(sample_time), max(sample_time), sql_id,session_id, sql_plan_hash_value 
from v$active_session_history where session_id=12574 --and session_id=10507 and sample_time > sysdate - 5.5 --and sql_id='atrf8xc1y79nh'
group by sql_id, sql_plan_hash_value,session_id order by 1 desc

3167466150

select * from v$sqlarea where sql_id in (
'8ax8z22ag24tu',
'5q4vg24q8hdgu',
'4n1hywnk5dr0z',
'20prknr44vmma',
'4p9b2bmytnra2')

COUNT(*)	SQL_ID
665	8ax8z22ag24tu
595	5q4vg24q8hdgu
471	17f22yp2u1u6w
264	1zt2dyjnra47k
180	4n1hywnk5dr0z
166	20prknr44vmma
123	9byzn65y284ua
121	0p6nxhsjqwjbh
120	gnx0s6p2d0x7t
110	4p9b2bmytnra2


select * from v$sql where sql_id='4p9b2bmytnra2'
declare n number;
begin n := dbms_spm.drop_sql_plan_baseline( 'SQL_c91c730e963e5171'
                                 );
                                 end;

exec dbms_spm.

select * from dba_sql_plan_baselines where sql_handle='SQL_c91c730e963e5171' plan_name='SQL_PLAN_ck73m1ub3wnbjfcb33316'


NORM_4936_1


select * from V$session where sid in ( select session_id from dba_ddl_locks where name= 'PKG_EOR_AUX')


ACTION
ORION_34
EOR_RUL_DOUBLE_IDENT



BEGIN idwh2.run_process_job_logging('IDWH2.PR_EOR_IKO_NON_ER_IDENT', 'EOR_IKO_NON_ER_IDENT', 'ORION_34'); END;

/* Formatted on 20.12.2021 9:51:46 (QP5 v5.336) */
MERGE   /*+
      BEGIN_OUTLINE_DATA
      PQ_DISTRIBUTE_WINDOW(@"SEL$37633EB5" 0)
      PQ_DISTRIBUTE(@"SEL$37633EB5_2" "M"@"SEL$37633EB5_2" NONE BROADCAST)
      PQ_DISTRIBUTE(@"SEL$37633EB5_1" "M"@"SEL$3" NONE BROADCAST)
      NLJ_BATCHING(@"SEL$37633EB5_2" "M"@"SEL$37633EB5_2")
      USE_NL(@"SEL$37633EB5_2" "M"@"SEL$37633EB5_2")
      NLJ_BATCHING(@"SEL$37633EB5_1" "M"@"SEL$3")
      USE_NL(@"SEL$37633EB5_1" "M"@"SEL$3")
      LEADING(@"SEL$37633EB5_2" "CO"@"SEL$37633EB5_2" "M"@"SEL$37633EB5_2")
      LEADING(@"SEL$37633EB5_1" "CO"@"SEL$3" "M"@"SEL$3")
      INDEX(@"SEL$37633EB5_2" "M"@"SEL$37633EB5_2" ("IDW_MR_MASTER"."ETALON_REGISTRY_ID"))
      BATCH_TABLE_ACCESS_BY_ROWID(@"SEL$37633EB5_2" "CO"@"SEL$37633EB5_2")
      INDEX_RS_ASC(@"SEL$37633EB5_2" "CO"@"SEL$37633EB5_2" ("IDWH2_ETALON_NR_KO"."FULL_NAME" "IDWH2_ETALON_NR_KO"."OKSM_CODE"))
      INDEX(@"SEL$37633EB5_1" "M"@"SEL$3" ("IDW_MR_MASTER"."ETALON_REGISTRY_ID"))
      BATCH_TABLE_ACCESS_BY_ROWID(@"SEL$37633EB5_1" "CO"@"SEL$3")
      INDEX_RS_ASC(@"SEL$37633EB5_1" "CO"@"SEL$3" "IDWH2_ETALON_NR_KO_IDX12")
      PQ_DISTRIBUTE(@"SEL$6BD737F4_2" "M"@"SEL$6BD737F4_2" NONE BROADCAST)
      PQ_DISTRIBUTE(@"SEL$6BD737F4_1" "M"@"SEL$5" NONE BROADCAST)
      NLJ_BATCHING(@"SEL$6BD737F4_2" "M"@"SEL$6BD737F4_2")
      USE_NL(@"SEL$6BD737F4_2" "M"@"SEL$6BD737F4_2")
      NLJ_BATCHING(@"SEL$6BD737F4_1" "M"@"SEL$5")
      USE_NL(@"SEL$6BD737F4_1" "M"@"SEL$5")
      LEADING(@"SEL$6BD737F4_2" "CO"@"SEL$6BD737F4_2" "M"@"SEL$6BD737F4_2")
      LEADING(@"SEL$6BD737F4_1" "CO"@"SEL$5" "M"@"SEL$5")
      INDEX(@"SEL$6BD737F4_2" "M"@"SEL$6BD737F4_2" ("IDW_MR_MASTER"."ETALON_REGISTRY_ID"))
      BATCH_TABLE_ACCESS_BY_ROWID(@"SEL$6BD737F4_2" "CO"@"SEL$6BD737F4_2")
      INDEX_RS_ASC(@"SEL$6BD737F4_2" "CO"@"SEL$6BD737F4_2" ("IDWH2_ETALON_NR_KO"."FULL_NAME" "IDWH2_ETALON_NR_KO"."OKSM_CODE"))
      INDEX(@"SEL$6BD737F4_1" "M"@"SEL$5" ("IDW_MR_MASTER"."ETALON_REGISTRY_ID"))
      BATCH_TABLE_ACCESS_BY_ROWID(@"SEL$6BD737F4_1" "CO"@"SEL$5")
      INDEX_RS_ASC(@"SEL$6BD737F4_1" "CO"@"SEL$5" "IDWH2_ETALON_NR_KO_IDX12")
      USE_NL(@"SEL$F5BB74E1" "IC"@"SEL$2")
      LEADING(@"SEL$F5BB74E1" "RES"@"SEL$1" "IC"@"SEL$2")
      BATCH_TABLE_ACCESS_BY_ROWID(@"SEL$F5BB74E1" "IC"@"SEL$2")
      INDEX_RS_ASC(@"SEL$F5BB74E1" "IC"@"SEL$2" ("TMP_EOR_IDENT_CANDIDATE"."FIND_CANDIDATE_ID" "TMP_EOR_IDENT_CANDIDATE"."ETALON_REGISTRY_ID"))
      NO_ACCESS(@"SEL$F5BB74E1" "RES"@"SEL$1")
      USE_MERGE_CARTESIAN(@"MRG$1" "RES"@"MRG$1")
      USE_MERGE_CARTESIAN(@"MRG$1" "IC"@"MRG$1")
      LEADING(@"MRG$1" "from$_subquery$_012"@"MRG$1" "IC"@"MRG$1" "RES"@"MRG$1")
      NO_ACCESS(@"MRG$1" "RES"@"MRG$1")
      FULL(@"MRG$1" "IC"@"MRG$1")
      NO_ACCESS(@"MRG$1" "from$_subquery$_012"@"MRG$1")
      MERGE(@"SEL$3")
      OUTLINE(@"SEL$37633EB5")
      MERGE(@"SEL$5")
      OUTLINE(@"SEL$6BD737F4")
      OUTLINE(@"SEL$5")
      OUTLINE(@"SEL$6")
      OUTLINE(@"SEL$2")
      OUTLINE(@"SEL$1")
      OUTLINE(@"SEL$3")
      OUTLINE(@"SEL$4")
      OUTLINE_LEAF(@"SEL$37633EB5_2")
      USE_CONCAT(@"SEL$37633EB5" 8 OR_PREDICATES(1))
      OUTLINE_LEAF(@"SEL$37633EB5_1")
      OUTLINE_LEAF(@"SEL$6BD737F4_2")
      USE_CONCAT(@"SEL$6BD737F4" 8 OR_PREDICATES(1))
      OUTLINE_LEAF(@"SEL$6BD737F4_1")
      OUTLINE_LEAF(@"MRG$1")
      MERGE(@"SEL$5")
      OUTLINE_LEAF(@"SEL$6BD737F4")
      MERGE(@"SEL$2")
      OUTLINE_LEAF(@"SEL$F5BB74E1")
      MERGE(@"SEL$3")
      OUTLINE_LEAF(@"SEL$37633EB5")
      SHARED(16)
      ALL_ROWS
      OPT_PARAM('_fix_control' '17376322:0')
      OPT_PARAM('optimizer_dynamic_sampling' 6)
      OPT_PARAM('optimizer_index_caching' 32)
      DB_VERSION('12.1.0.2')
      OPTIMIZER_FEATURES_ENABLE('12.1.0.2')
      IGNORE_OPTIM_EMBEDDED_HINTS
      END_OUTLINE_DATA
  */
 INTO IDWH2.TMP_EOR_IDENT_CANDIDATE IC
     USING (SELECT M.ETALON_REGISTRY_ID,
                   M.EOR_H_ID,
                   COUNT (1) OVER (PARTITION BY 1)     CNT
              FROM IDWH2.IDWH2_ETALON_NR_KO  CO
                   INNER JOIN IDWH2.IDW_MR_MASTER M
                       ON M.ETALON_REGISTRY_ID = CO.ETALON_REGISTRY_ID
             WHERE     (CO.FULL_NAME = :B3 OR CO.SHORT_NAME = :B2)
                   AND M.FILIAL_SIGN = NVL ( :B1, '0')
                   AND M.DELETED_SIGN = '0') RES
        ON (    IC.ETALON_REGISTRY_ID = RES.ETALON_REGISTRY_ID
            AND IC.FIND_CANDIDATE_ID = :B4)
WHEN NOT MATCHED
THEN
    INSERT     (IC.FIND_CANDIDATE_ID,
                IC.ETALON_REGISTRY_ID,
                IC.EOR_H_ID,
                IC.WEIGHT)
        VALUES ( :B4,
                RES.ETALON_REGISTRY_ID,
                RES.EOR_H_ID,
                1 / (1 + LOG (10, RES.CNT)))
         WHERE RES.CNT <= :B5
WHEN MATCHED
THEN
    UPDATE SET IC.WEIGHT = IC.WEIGHT + 1 / (1 + LOG (10, RES.CNT))
             WHERE RES.CNT <= :B5
PAK_OA_PERSON_SIGN_INS
select * from v$sql where sql_id='1bu5xpjqs4kzf'

select * from v$sql where sql_id='00znuadhbc1bq'

select * from v$session where sid=9455
16845733
16845750

ORION_19

SQL_PROFILE	SQL_PATCH	SQL_PLAN_BASELINE
SYS_SQLPROF_017dc7c633f50000		SQL_PLAN_5rb3bnnghp5g9e5578f80
exec DBMS_SQLTUNE.DROP_SQL_PROFILE ('SYS_SQLPROF_017dc7c633f50000');
DBMS_SPM


select * from dba_sql_plan_baselines where sql_handle='SQL_5bac6ba51f0a95e9' 


select * from table(DBMS_XPLAN.DISPLAY_SQL_PLAN_BASELINE (   'SQL_5bac6ba51f0a95e9',
   format          => 'OUTLINE'));


SQL_PLAN_5rb3bnnghp5g91e757ec3   
SQL_PLAN_5rb3bnnghp5g95cf70015
plan_name= 'SQL_PLAN_5rb3bnnghp5g9f53393e6'  'SQL_PLAN_5rb3bnnghp5g9e5578f80'
declare 
 n number;
begin
 n :=   dbms_spm.drop_sql_plan_baseline( sql_handle  =>'SQL_5bac6ba51f0a95e9');
end;
 
                                   plan_name=>''
                                 )
  RETURN PLS_INTEGER;

ACTION
ORION_34
EOR_RUL_DOUBLE_IDENT

select * from dba_objects where object_id=1966347
BEGIN idwh2.run_process_job_logging('IDWH2.PR_EOR_IKO_NON_ER_IDENT', 'EOR_IKO_NON_ER_IDENT', 'ORION_34'); END;

execute dbms_stats.gather_table_stats(ownname => 'IDWH2', tabname => 'TMP_EOR_IDENT_CANDIDATE', estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE, method_opt => 'FOR ALL COLUMNS SIZE AUTO', cascade => TRUE);

--��������� ������� ������� �������� (�� ���������� ������ � �����������)
SELECT 
 I.STATE_ID,
 ST.NAME,
 COUNT(1) CNT,
 DK.NAME SOURCE_NAME,
 M.SOURCE_ID,
 I.PRIORITY 
FROM IDWH2.IDW_SY_WORKFLOW_INFO I
 INNER JOIN IDWH2.IDW_MR_SUBJECT_MENTION M
   ON TO_NUMBER(I.OBJECT_ID) = M.EOR_SUBJECT_MENTION_ID
 INNER JOIN IDWH2.IDW_SR_DATA_KIND DK
   ON M.SOURCE_ID = DK.ID  
 INNER JOIN IDWH2.IDW_SR_WORKFLOW_STATE ST 
   ON I.WORKFLOW_ID = ST.WORKFLOW_ID
      AND I.STATE_ID = ST.ID 
WHERE I.WORKFLOW_ID = 94
  AND I.STATE_ID = 943 
GROUP BY M.SOURCE_ID, DK.NAME, STATE_ID, ST.NAME, I.PRIORITY
ORDER BY I.PRIORITY DESC,M.SOURCE_ID;

CNT 9:58
520360
2
16
2


CNT 11:40
520473
2
16
2



select s2.c,s2.event,s2.p1,s2.p1text,s2.p2,s2.p2text, s1.* from v$session s1, 
(select final_blocking_session,event,p1,p1text,p2,p2text,count(*) c from v$session group by final_blocking_session,event,p1,p1text,p2,p2text) s2 where s1.sid=s2. final_blocking_session

00001FA800000000

select * from v$session where event in ('library cache: mutex X','cursor: pin S wait on X','cursor: pin S wait on X')


select distinct  --q.sql_text,
q2.sql_text, s.*
--event,wait_time,seconds_in_wait,state,sid,s.program, s.module,s.action 
from v$session s, --v$sql q, 
v$sql q2 where (--prev_
sql_id=q2.sql_id 
--or q.sql_id=s.sql_id
) and event in ('library cache: mutex X','cursor: pin S wait on X','cursor: pin S wait on X') and seconds_in_wait > 5;

PROGRAM
oracle@T82A (J010)
Server.exe
Server.exe
oracle@T82A (J041)
oracle@T82A (J000)

select * from dba_scheduler_running_jobs from_run_details

select * from 
PROGNOZ_43

select * from v$sgastat where upper(name) like 'PX%' 44G

select * from v$process where program like 'oracle@T82A (P%' 2197

select * from v$session where program like 'oracle@T82A (P%'

select * from v$sql where sql_id in ('30kguv3t5rm1n', 'fth50kpusn24d')

select * from v$mutex_sleep
select * from v$mutex_sleep_history
alter system kill session '14251,47164' immediate;

select * from dba_tables where trim(instances) not in( '0','1') 


ACTION
EOL_LOAD_12997272

PRSCME154217580_12997260

alter system enable restricted session;
alter system disable restricted session;



EOR_RUL_DOUBLE_IDENT
select * from v$sql where sql_id='b3h2tykc2588b'
select * from v$session where sid in (
12275,
9938,
3363,
7447)



select count(*),event from v$session where wait_class <>'Idle' group by event order by 1 desc

select rowid,dda_tbl.* from dda_tbl order by 1



--��� �������� ���������� ����� �������������� ��������
select count(1) cnt
from IDW_ARJ_OPERATION_4936_1
where opr_message_id > (select last_id from idw_rco_process_state where process_alias='NORM_4936_1' and rownum <= 1)
  and data_kind_id = 1101;
select count(1) cnt
from IDW_ARJ_OPERATION_4936_1
where opr_message_id > (select last_id from idw_rco_process_state where process_alias='NORM_4936_1' and rownum <= 1)
  and data_kind_id = 1102;
--��� �������� ��������� �������
select *
from idwh2.idw_arj_operation_4936_1 a
inner join idwh2.idw_oa_rco_err_process_persons b
 on a.opr_message_id = b.person_id
where b.process_alias = 'NORM_4936_1';
select *
from idwh2.idw_arj_operation_4936_1 a
inner join idwh2.idw_oa_rco_err_process_persons b
 on a.opr_message_id = b.person_id
where b.process_alias = 'NORM_4936_2';
