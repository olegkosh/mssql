select distinct job_name from dba_scheduler_job_run_details
where
    JOB_NAME in (
--- ������������ ����� ������������
select JOB_NAME from dba_scheduler_job_run_details 
where 
    LOG_DATE > '14/10/2022 03:00:04,711413 +03:00' 
and LOG_DATE < '14/10/2022 05:00:04,711413 +03:00'
and ACTUAL_START_DATE > '13/10/2022 20:16:04,711413 +03:00' 
and ACTUAL_START_DATE < '14/10/2022 02:16:04,711413 +03:00' 
--and RUN_DURATION > '+00 03:00:42.000000'
--and RUN_DURATION < '+00 14:00:42.000000'
--and additional_info='ORA-01014: ORACLE shutdown in progress'
and status='STOPPED' 
and JOB_NAME not in (select JOB_NAME from dba_scheduler_job_run_details where LOG_DATE > '14/10/2022 04:20:04,711413 +03:00') 
and JOB_NAME not in (select JOB_NAME from dba_scheduler_jobs where state='RUNNING') 
--order by ACTUAL_START_DATE;

)and    JOB_NAME in (
--- �������� ��������
select JOB_NAME from dba_scheduler_job_run_details 
where 
    LOG_DATE > '13/10/2022 06:00:04,711413 +03:00' 
and LOG_DATE < '13/10/2022 09:00:04,711413 +03:00'
and ACTUAL_START_DATE > '12/10/2022 20:00:04,711413 +04:00' 
and ACTUAL_START_DATE < '13/10/2022 02:16:04,711413 +03:00' 
--and RUN_DURATION > '+00 03:00:42.000000'
--and RUN_DURATION < '+00 14:00:42.000000'
--and additional_info='ORA-01014: ORACLE shutdown in progress'
--and status='STOPPED' 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_job_run_details where LOG_DATE > '14/10/2022 04:20:04,711413 +03:00') 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_jobs where state='RUNNING') 
--order by ACTUAL_START_DATE; 
)  and   JOB_NAME in (
--- �������� ��������
select job_name from dba_scheduler_job_run_details 
where 
    LOG_DATE > '12/10/2022 06:00:04,711413 +03:00' 
and LOG_DATE < '12/10/2022 09:00:04,711413 +03:00'
and ACTUAL_START_DATE > '11/10/2022 20:00:04,711413 +04:00' 
and ACTUAL_START_DATE < '12/10/2022 02:16:04,711413 +03:00' 
--and RUN_DURATION > '+00 03:00:42.000000'
--and RUN_DURATION < '+00 14:00:42.000000'
--and additional_info='ORA-01014: ORACLE shutdown in progress'
--and status='STOPPED' 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_job_run_details where LOG_DATE > '14/10/2022 04:20:04,711413 +03:00') 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_jobs where state='RUNNING') 
--order by ACTUAL_START_DATE; 
)  and   JOB_NAME in (
--- �������� ��������
select job_name from dba_scheduler_job_run_details 
where 
    LOG_DATE > '11/10/2022 06:00:04,711413 +03:00' 
and LOG_DATE < '11/10/2022 09:00:04,711413 +03:00'
and ACTUAL_START_DATE > '10/10/2022 20:00:04,711413 +04:00' 
and ACTUAL_START_DATE < '11/10/2022 02:16:04,711413 +03:00' 
--and RUN_DURATION > '+00 03:00:42.000000'
--and RUN_DURATION < '+00 14:00:42.000000'
--and additional_info='ORA-01014: ORACLE shutdown in progress'
--and status='STOPPED' 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_job_run_details where LOG_DATE > '14/10/2022 04:20:04,711413 +03:00') 
--and JOB_NAME not in (select JOB_NAME from dba_scheduler_jobs where state='RUNNING') 
--order by ACTUAL_START_DATE; 
)


--
select * from sys.dba_scheduler_jobs where job_name='SUBJECT_OPERATION_IDENT_JOB';
select * from sys.dba_scheduler_jobs where state='RUNNING'
select distinct state from sys.dba_scheduler_jobs




ORA-01014: ORACLE shutdown in progress


select distinct STATUS from dba_scheduler_job_run_details 

BAIKAL_JOB9
nko_everyday_modify