-- ��������� ������
define d1 = date'2023-02-28';
define d2 = date'2023-04-01';

select t.ts_list,t.cnt,f.fnames from 
(with t as (
            select case row_number() over (partition by tablespace_name order by 1) 
                    when 1 then tablespace_name 
                   end tablespace_name, 
                   count(*) over () cnt,
                   name
             from v$datafile,
                  dba_data_files 
                  where file_id=file# and creation_time between &&d1  and &&d2
           ) 
select listagg(t.tablespace_name,', ') within group (order by t.tablespace_name) ts_list, avg(cnt) cnt
from t) t,
(select 
trunc(v.creation_time) cr_time,
-- listagg(d.tablespace_name,', ') within group (order by rownum) tsname,
listagg(name,', ') within group (order by rownum)||' ('||trunc(creation_time)||')' fnames
from v$datafile v, dba_data_files d
where file_id=file# and 
creation_time between &&d1  and &&d2
group by trunc(v.creation_time)) f
order by f.cr_time;


-- �������� �� ������
select trunc(creation_time),listagg(tablespace_name,', ') within group (order by rownum) ,
listagg(name,', ') within group (order by rownum)||' ('||trunc(creation_time)||')'
from v$datafile 
inner join dba_data_files on file_id=file# 
where creation_time between date'2022-05-27'  and date'2022-06-02' group by trunc(creation_time) 
order by 1;