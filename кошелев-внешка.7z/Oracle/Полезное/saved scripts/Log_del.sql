alter session SET NLS_DATE_FORMAT = 'DD/MM/YYYY';

begin
  sys.dbms_scheduler.create_job(
    job_name => 'LOG_DEL_2015', 
    job_type => 'PLSQL_BLOCK',
    enabled => true,
    auto_drop => true,
    job_action => q'[ 
loop
    delete  from KOFR.LOG_CHANGE
            where CHANGE_USER in ('KOFR','BAIKAL','STMTEH')
                and CHANGE_DATE < TO_DATE('31/12/2015','DD/MM/YYYY')
                and ROWNUM <=50000;
    EXIT WHEN SQL%ROWCOUNT=0;
    commit;
end loop;
commit;
]'
);
end;



 
delete from KOFR.LOG_CHANGE
where CHANGE_USER in ('KOFR','BAIKAL','STMTEH')
and CHANGE_DATE < sysdate-90;
commit;





select count (*) from KOFR.LOG_CHANGE
            where CHANGE_USER in ('KOFR','BAIKAL','STMTEH')
                and 
                CHANGE_DATE between TO_DATE('31/12/2016','DD/MM/YYYY')and  TO_DATE('01/01/2018','DD/MM/YYYY')                and ROWNUM <=10000;;
                
                11601938680 15:55
                8051075814 users
                8015981522
                8012970097
                 307593007
                 258723007
                 258613007
                 257013007 17:21
                 256413007 17:33
                 
                 SPI_RELATIVE
                 
                 BAIKAL_JOB9
                 
                 
select sysdate-90, count (*) from KOFR.LOG_CHANGE
            where CHANGE_USER in ('KOFR','BAIKAL','STMTEH')
                and 
                CHANGE_DATE < sysdate-90;
                CHANGE_DATE < TO_DATE('31/12/2021','DD/MM/YYYY')
                and  TO_DATE('01/01/2018','DD/MM/YYYY')                and ROWNUM <=10000;;         
8432438     17:49 
8432438
8432438
8132438


92521673 '31/12/2022'
311429969

SYSDATE-90	COUNT(*)
02.03.2023 11:02:26	311432637


LOG_CHANGE_DEL
LOG_CHANGE_DELETE                   