select * from v$session where sid in (
select session_id from dba_ddl_locks where name='PKG_EOR_AUX'
);
