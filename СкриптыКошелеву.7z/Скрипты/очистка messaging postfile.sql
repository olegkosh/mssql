/****** Скрипт для команды SelectTopNRows из среды SSMS  ******/
SELECT --COUNT(*)
TOP (1000) *
  FROM [Messaging].[dbo].[PostMessage] M
  right join [Messaging].[dbo].[PostMessageFile] f
  ON M.IDPostMessageFile = F.IDPostMessageFile
  WHERE CreateDate < '2020-01-01'

  SELECT --COUNT(*)
TOP (1000) *
  FROM [Messaging].[dbo].[PostMessage]-- M
  --right join [Messaging].[dbo].[PostMessageFile] f
  --ON M.IDPostMessageFile = F.IDPostMessageFile
  WHERE CreateDate < '2020-01-01'

  /****** Скрипт для команды SelectTopNRows из среды SSMS  ******/



--  SELECT COUNT(*)
----TOP (1000) *
--  FROM [Messaging].[dbo].[PostMessage]
--  WHERE CreateDate < '2020-01-01'
  --ORDER BY CreateDate
  --ORDER BY CreateDate

  SELECT COUNT(*)
 --TOP (1000) *
  FROM [Messaging].[dbo].[PostMessageFile] F
  inner join [Messaging].[dbo].[PostMessage] M
  ON M.IDPostMessageFile = F.IDPostMessageFile 
  WHERE CreateDate < '2020-01-01'-- and M.IDPostMessageFile is not null
  --157035
  --ORDER BY CreateDate

   SELECT COUNT(*)
	FROM [Messaging].[dbo].[PostMessage]
	WHERE CreateDate < '2020-01-01'
	--1132117


 -- BEGIN tran
  DELETE TOP (10000) f
  FROM [Messaging].[dbo].[PostMessageFile] F
  inner join [Messaging].[dbo].[PostMessage] M
  ON M.IDPostMessageFile = F.IDPostMessageFile 
  WHERE CreateDate < '2020-01-01'
 -- Rollback tran

   -- BEGIN tran
    DELETE TOP (100000)
	FROM [Messaging].[dbo].[PostMessage]
	WHERE CreateDate < '2020-01-01'
--	Rollback tran
