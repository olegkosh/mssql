SELECT DB_ID() AS [Databese ID];
GO