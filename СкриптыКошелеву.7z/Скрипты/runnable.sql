select DB_NAME(dbid) as db, spid as idproc, loginame, PROGRAM_NAME, status
from sys.sysprocesses
where status = 'running' or status = 'runnable'