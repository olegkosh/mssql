select CONVERT(int, sum
(
CASE a.objtype
WHEN 'Adhoc'
then 1 else 0 end)
* 1.00 / count(*) * 100)
as 'Ad-hoc query %'
FROM sys.dm_exec_cached_plans as a



select usecounts,cacheobjtype, objtype, size_in_bytes/1024 as 'SIZE(KB)', text
from sys.dm_exec_cached_plans
cross apply sys.dm_exec_sql_text(plan_handle)
where usecounts = 1 and objtype = 'Adhoc'
ORDER BY size_in_bytes/1024 DESC;



--select usecounts,cacheobjtype, objtype, size_in_bytes/1024 as SIZEKB, text
----left(text,50) as ltext
--from sys.dm_exec_cached_plans
--cross apply sys.dm_exec_sql_text(plan_handle)
--where usecounts = 1 and objtype = 'Adhoc'
--and text like '%IDCounteragent%'
----GROUP BY usecounts,cacheobjtype, objtype, size_in_bytes/1024,
----left(text,50)
--ORDER BY size_in_bytes/1024 DESC;


select SUM(usecounts) as counts--, cacheobjtype, objtype, 
,SUM(size_in_bytes/1024) as SIZEKB, 
left(text,50) as ltext --50
from sys.dm_exec_cached_plans
cross apply sys.dm_exec_sql_text(plan_handle)
where usecounts = 1 and objtype = 'Adhoc'
GROUP BY left(text,50)
ORDER BY SUM(size_in_bytes/1024)
DESC;


