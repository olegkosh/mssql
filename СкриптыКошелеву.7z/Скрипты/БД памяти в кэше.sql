SELECT
CASE database_id
WHEN 32767 THEN 'ResourceDB'
ELSE db_name(database_id)
END AS database_name, count(1)/128 AS megabytes_in_cache
FROM sys.dm_os_buffer_descriptors
GROUP BY DB_NAME(database_id), database_id
ORDER BY megabytes_in_cache DESC;
--ORDER BY database_name DESC;