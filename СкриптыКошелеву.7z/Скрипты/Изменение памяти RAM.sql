GO
--sp_configure 'show advanced options', 1;
GO
--RECONFIGURE;
GO
--sp_configure 'max server memory', 425984;
GO
--RECONFIGURE;
GO
SELECT [name], [value], [value_in_use]
FROM sys.configurations
WHERE [name] = 'max server memory (MB)' OR [name] = 'min server memory';


