SELECT qs.plan_handle,qs.creation_time, qs.last_execution_time, qs.execution_count, st.text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(qs.plan_handle) AS st
WHERE st.text LIKE '%CREATE TABLE #%' OR st.text LIKE '%INSERT INTO #%'
ORDER BY qs.execution_count desc, qs.creation_time desc