select jb.name, jb.* from sysjobsteps js
left join sysjobs jb on js.job_id = jb.job_id
where js.command like '%InfRes_Synch_FORS%'
