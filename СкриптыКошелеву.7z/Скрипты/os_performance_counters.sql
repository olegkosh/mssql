--DBCC FREEPROCCACHE;
--DBCC DROPCLEANBUGGERS CHECKPOINT

SELECT *
FROM sys.dm_os_performance_counters
--WHERE object_name LIKE '%Access Methods%'
--WHERE object_name LIKE '%Access Metho%'
WHERE object_name LIKE '%Buffer Manager%';
--WHERE
SELECT *
FROM sys.dm_os_performance_counters
WHERE [counter_name] = 'Page life expectancy'
--WHERE counter_name = 'Buffer cache hit ratio'
--WHERE counter_name LIKE '%cache%';

--Select * from SYSPROCESSES
--ORDER BY cpu

--�������� ����������
--DBCC SQLPERF (N'sys.dm_os_wait_stats', CLEAR);
--GO

SELECT *
FROM sys.dm_os_performance_counters
WHERE --counter_name like '%Log Flush Waits%' or counter_name like '%Log Flush Wait Time%' or 
counter_name like '%Log Flushes%' and object_name LIKE '%Databases%'
order by cntr_value desc

select * from sys.sql_logins
order by create_date desc


SYS.DM_EXEC_QUERY_STATS
SYS.DM_OS_SCHEDULERS
SYS.DM_IO_PENDING_IO_REQUESTS
SYS.DM_OS_WAIT_STATS
