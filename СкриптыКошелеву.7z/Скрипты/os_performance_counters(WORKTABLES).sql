SELECT a.object_name,'WorktablesFromCacheRatio' as counter_name,'' as instance_name,cast(a.cntr_value*100.0/b.cntr_value as dec(4,2)) as cntr_value
FROM sys.dm_os_performance_counters a
 JOIN (SELECT cntr_value,OBJECT_NAME
  FROM sys.dm_os_performance_counters
  WHERE counter_name='Worktables From Cache Base' AND OBJECT_NAME='SQLServer:Access Methods') b
  ON a.OBJECT_NAME=b.OBJECT_NAME
WHERE a.counter_name='Worktables From Cache Ratio' AND a.OBJECT_NAME='SQLServer:Access Methods'
SELECT *
FROM sys.dm_os_performance_counters
--WHERE counter_name LIKE '%Worktables from cache%';
WHERE counter_name LIKE '%Workt%';
--WHERE object_name LIKE '%Access Methods%';


--��������, ��� KSAND_CR_GEN, KSAND_CR_MSG_PROCESS (���������� �� �������)
--10:00 Worktables from Cache Ratio 5706052
--�������� KSAND_CR_MSG_PROCESS 
--14:00 Worktables from Cache Ratio 5809308
--		Worktables from Cache Base 7315986
-- 79%

--16:00 Worktables from Cache Ratio 5861150
--		Worktables from Cache Base 7437727

--17:00 Worktables from Cache Ratio 5891057
--		Worktables from Cache Base 7504409

--09:30 Worktables from Cache Ratio 5997876
--		Worktables from Cache Base 8187134

--11:00 Worktables from Cache Ratio 6037214
--		Worktables from Cache Base 8278904

--12:00 Worktables from Cache Ratio 6705504
--		Worktables from Cache Base 8359140

--13:00 Worktables from Cache Ratio 6089803
--		Worktables from Cache Base 8396846

--14:00 Worktables from Cache Ratio 6110856
--		Worktables from Cache Base 8459138

--15:00 Worktables from Cache Ratio 6130401
--		Worktables from Cache Base 8504634

--�������� ������ 5283

--17:00 Worktables from Cache Ratio 6183141
--		Worktables from Cache Base 8623611

--17:40 Worktables from Cache Ratio 6200784
--		Worktables from Cache Base 8664928

--09:30	Worktables from Cache Ratio 6299393
--		Worktables from Cache Base 9287298

--11:00	Worktables from Cache Ratio 6299393
--		Worktables from Cache Base 9287298
--68%

--12:00	Worktables from Cache Ratio 6362430
--		Worktables from Cache Base 9434975
--67%

--14:00	Worktables from Cache Ratio 6403269
--		Worktables from Cache Base 9534617
--67%

--15:00	Worktables from Cache Ratio 6430316
--		Worktables from Cache Base 9592520
--67%

--16:30	Worktables from Cache Ratio 6478376
--		Worktables from Cache Base	9691642
--67%

--21.11
--10:00	Worktables from Cache Ratio 6721158
--		Worktables from Cache Base 12104831
--56%

--13:00	Worktables from Cache Ratio 6788113
--		Worktables from Cache Base 12258492
--55%

--23.11

--10:00	Worktables from Cache Ratio 7319730
--		Worktables from Cache Base 14191296
--52%

--11:00	Worktables from Cache Ratio 7344115
--		Worktables from Cache Base 14250365
--52%

--13:00	Worktables from Cache Ratio 7385386
--		Worktables from Cache Base 14345037
--51%

--17:00	Worktables from Cache Ratio 7475560
--		Worktables from Cache Base 14557048
--51%

--24.11

--10:00	Worktables from Cache Ratio 7604360
--		Worktables from Cache Base 15203577
--50%

--12:00	Worktables from Cache Ratio 7656660
--		Worktables from Cache Base 15322074
--50%

--16:00	Worktables from Cache Ratio 7752311
--		Worktables from Cache Base 15532529
--50%

--17:00	Worktables from Cache Ratio 7779449
--		Worktables from Cache Base 15589773
--50%

--26.11.2022
--10:00	Worktables from Cache Ratio 7963304
--		Worktables from Cache Base 16314148
--49%

--12:00	Worktables from Cache Ratio 8005458
--		Worktables from Cache Base 16398949
--49%

--16:00	Worktables from Cache Ratio 8094445
--		Worktables from Cache Base 16581032
--49%

--28.11
--10:30	Worktables from Cache Ratio 8454942
--		Worktables from Cache Base 18884148
--45%

--15:30	Worktables from Cache Ratio 8584336
--		Worktables from Cache Base 19149811
--45%

--29.11
--11:30	Worktables from Cache Ratio 8808246
--		Worktables from Cache Base 19921159
--44%

--30.11
--09:45	Worktables from Cache Ratio 9080599
--		Worktables from Cache Base 20770059
--44%

--11:00	Worktables from Cache Ratio 9117103
--		Worktables from Cache Base 20839561
--44%

--15:30	Worktables from Cache Ratio 9237805
--		Worktables from Cache Base 21075465
--44%

--17:00	Worktables from Cache Ratio 9284169
--		Worktables from Cache Base 21159494
--44%

--01.12
--09:00	Worktables from Cache Ratio 9404771
--		Worktables from Cache Base 21683460
--43%

--15:30	Worktables from Cache Ratio 9566293
--		Worktables from Cache Base 22009909
--43%

--17:20	Worktables from Cache Ratio 9628515
--		Worktables from Cache Base 22128780
--44%

--02.12
--9:30	Worktables from Cache Ratio 9741676
--		Worktables from Cache Base 22648535
--43%

--12:00	Worktables from Cache Ratio 9807799
--		Worktables from Cache Base22772745
--43%

--15:00	Worktables from Cache Ratio 9878329
--		Worktables from Cache Base 22924369
--43%

--16:30	Worktables from Cache Ratio 9912263
--		Worktables from Cache Base 22994284
--43.11%

--05.12 
--09:30	Worktables from Cache Ratio 10167473
--		Worktables from Cache Base	25017536
--40.64%

--10:15	Worktables from Cache Ratio 10173891
--		Worktables from Cache Base	25030013
--40.65%

--10:46	Worktables from Cache Ratio 10188406
--		Worktables from Cache Base	25058186
--40.66%

--11:05	Worktables from Cache Ratio 10196882
--		Worktables from Cache Base	25075107
--40.67%

--11:45	Worktables from Cache Ratio 10216822
--		Worktables from Cache Base	25112231
--40.68%

--11:50	Worktables from Cache Ratio 10219794
--		Worktables from Cache Base	25117452
--40.69%

--12:00	Worktables from Cache Ratio 10226953
--		Worktables from Cache Base	25129045
--40.70%

--12:20	Worktables from Cache Ratio 10237460
--		Worktables from Cache Base	25147751
--40.71%

--12:40	Worktables from Cache Ratio 10246448
--		Worktables from Cache Base	25164647
--40.72%


--06.12
--9:40	Worktables from Cache Ratio 10475980
--		Worktables from Cache Base	25928694
--40.40%

--11:30	Worktables from Cache Ratio 10529759
--		Worktables from Cache Base	26029784
--40.45%

--11:50	Worktables from Cache Ratio 10535011
--		Worktables from Cache Base	26039879
--40.46%

--12:05	Worktables from Cache Ratio 10544250
--		Worktables from Cache Base	26055770
--40.47%

--12:20	Worktables from Cache Ratio 10550612
--		Worktables from Cache Base	26066751
--40.48%

--13:15	Worktables from Cache Ratio 10569418
--		Worktables from Cache Base	26106953
--40.49%

--14:48 Worktables from Cache Ratio 10605115
--		Worktables from Cache Base	26177769
--40.51%

--15:00 Worktables from Cache Ratio 10610262
--		Worktables from Cache Base	26187268
--40.52%

--15:20 Worktables from Cache Ratio 10610262
--		Worktables from Cache Base	26187268
--40.53%

--15:55	Worktables from Cache Ratio 10634802
--		Worktables from Cache Base	26233141
--40.54%

--16:20	Worktables from Cache Ratio 10646514
--		Worktables from Cache Base	26255649
--40.55%

--16:50	Worktables from Cache Ratio 10660706
--		Worktables from Cache Base	26282661
--40.56%

--17:15	Worktables from Cache Ratio 10660706
--		Worktables from Cache Base	26282661
--40.57%

--07.12
--09:45	Worktables from Cache Ratio 10789911
--		Worktables from Cache Base	26843008
--40.20%

--10:15	Worktables from Cache Ratio 10803800
--		Worktables from Cache Base	26869248
--40.21%

--10:55	Worktables from Cache Ratio 10819377
--		Worktables from Cache Base	26901911
--40.22%

--13:00	Worktables from Cache Ratio 10869808
--		Worktables from Cache Base	26901911
--40.25%

--15:15	Worktables from Cache Ratio 10918650
--		Worktables from Cache Base	27108719
--40.28%

--16:29	Worktables from Cache Ratio 10937806
--		Worktables from Cache Base	27150036
--40.29%

--16:50	Worktables from Cache Ratio 10955306
--		Worktables from Cache Base	27185468
--40.30%

--17:05	Worktables from Cache Ratio 10962854
--		Worktables from Cache Base	27198859
--40.31%

--08.12
--09:40	Worktables from Cache Ratio 11080969
--		Worktables from Cache Base	27746264
--39.94%

--10:30	Worktables from Cache Ratio 11102990
--		Worktables from Cache Base	27790053
--39.95%

--10:45	Worktables from Cache Ratio 11109018
--		Worktables from Cache Base	27801008
--39.96%

--11:20	Worktables from Cache Ratio 11121937
--		Worktables from Cache Base	27828334
--39.97%

--11:50	Worktables from Cache Ratio 11135998
--		Worktables from Cache Base	27853744
--39.98%

--12:10	Worktables from Cache Ratio 11147496
--		Worktables from Cache Base	27872619
--39.99%

--12:25	Worktables from Cache Ratio 11151657
--		Worktables from Cache Base	27882621
--40.00%

--16:00	Worktables from Cache Ratio 11229255
--		Worktables from Cache Base	28046323
--40.04%

--16:15	Worktables from Cache Ratio 11237849
--		Worktables from Cache Base	28062580
--40.05%

--17:15	Worktables from Cache Ratio 11262588
--		Worktables from Cache Base	28108236
--40.07%

--09.11
--10:00	Worktables from Cache Ratio 11407017
--		Worktables from Cache Base	28683530
--39.77%

--11:10	Worktables from Cache Ratio 11433160
--		Worktables from Cache Base	28738622
--39.78%

--11:17	Worktables from Cache Ratio 11436436
--		Worktables from Cache Base	28745110
--39.79%

--15:35	Worktables from Cache Ratio 11530951
--		Worktables from Cache Base	28946961
--39.83%

--12.12
--9:40	Worktables from Cache Ratio 11795660
--		Worktables from Cache Base	30908317
--38.16%

--10:35	Worktables from Cache Ratio 11817778
--		Worktables from Cache Base	30951301
--38.18%

--11:30	Worktables from Cache Ratio 11840933
--		Worktables from Cache Base	30996225
--38.21%

--12:00	Worktables from Cache Ratio 11856589
--		Worktables from Cache Base	31025703
--38.22%

--15:55	Worktables from Cache Ratio 11939835
--		Worktables from Cache Base	31203501
--38.26%

--16:10	Worktables from Cache Ratio 11945155
--		Worktables from Cache Base	31214722
--38.27%

--16:35	Worktables from Cache Ratio 11956264
--		Worktables from Cache Base	31236881
--38.27%

--16:45	Worktables from Cache Ratio 11958672
--		Worktables from Cache Base	31242028
--38.28%

--17:25	Worktables from Cache Ratio 11973915
--		Worktables from Cache Base	31273503
--38.29%

--09:40	Worktables from Cache Ratio 12090619
--		Worktables from Cache Base	31792484
--38.03%

--11:30	Worktables from Cache Ratio 12139781
--		Worktables from Cache Base	31886798
--38.07%

--14.12
--12:50	Worktables from Cache Ratio 12484377
--		Worktables from Cache Base	32844998
--38.01%

--15:10	Worktables from Cache Ratio 12529882
--		Worktables from Cache Base	32925149
--38.06%

--16:10	Worktables from Cache Ratio 12550574
--		Worktables from Cache Base	32947329
--38.09%

--16:13	Worktables from Cache Ratio 12551956
--		Worktables from Cache Base	32948858
--38.10%

--17:40	Worktables from Cache Ratio 12584248
--		Worktables from Cache Base	32983633
--38.15%

--15.12
--13:20	Worktables from Cache Ratio 12765192
--		Worktables from Cache Base	33179775
--38.47%

--14:55	Worktables from Cache Ratio 12800522
--		Worktables from Cache Base	33217747
--38.54%

--16:30	Worktables from Cache Ratio 12836193
--		Worktables from Cache Base	33255980
--38.60%

--17:21	Worktables from Cache Ratio 12857917
--		Worktables from Cache Base	33279086
--38.64%

--16.12
--09:45	Worktables from Cache Ratio 12967128
--		Worktables from Cache Base	33395620
--38.83%

--10:35	Worktables from Cache Ratio 12983274
--		Worktables from Cache Base	33413252
--38.86%

--12:50	Worktables from Cache Ratio 13025077
--		Worktables from Cache Base	33461704
--38.93%

--13:10	Worktables from Cache Ratio 13031675
--		Worktables from Cache Base	33468922
--38.94%

--14:50	Worktables from Cache Ratio 13066611
--		Worktables from Cache Base	33506473
--39.00%

--19.12
--09:45	Worktables from Cache Ratio 13348882
--		Worktables from Cache Base	33802244
--39.49%

--27.12
--11:20	Worktables from Cache Ratio 15170057
--		Worktables from Cache Base	35749883
--42.43%

--11:50	Worktables from Cache Ratio 15181341
--		Worktables from Cache Base	35762213
--42.45%

--28.12
--10:35	Worktables from Cache Ratio 15488527
--		Worktables from Cache Base	36087467
--42.92%

--12:00	Worktables from Cache Ratio 15544570
--		Worktables from Cache Base	36149088
--43.00%

--30.12
--11:40	Worktables from Cache Ratio 16059444
--		Worktables from Cache Base	36709483
--43.75%

--10.01
--09:35	Worktables from Cache Ratio 16870207
--		Worktables from Cache Base	37559971
--44.92%

--11.01
--09:30	Worktables from Cache Ratio 17152772
--		Worktables from Cache Base	37865714
--45.30%

--16.01
--15:20	Worktables from Cache Ratio 18186387
--		Worktables from Cache Base	38986406
--46.65%

--17.01
--17:47	Worktables from Cache Ratio 18530144
--		Worktables from Cache Base	39361410
--47.08%

--20.01
--10:35	Worktables from Cache Ratio 19200049
--		Worktables from Cache Base	40108896
--47.87%

--15:00	Worktables from Cache Ratio 19286126
--		Worktables from Cache Base	40204925
--47.97%

--27.01
--09:30	Worktables from Cache Ratio 20543175
--		Worktables from Cache Base	41577972
--49.41%


--31.01
--09:30	Worktables from Cache Ratio 21257247
--		Worktables from Cache Base	42340671
--50.21%

--07.02
--15:00	Worktables from Cache Ratio 23816683
--		Worktables from Cache Base	45041892
--52.88%
