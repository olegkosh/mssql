--USE
SELECT *
from sys.procedures
where OBJECT_DEFINITION(object_id) like '%delete%'