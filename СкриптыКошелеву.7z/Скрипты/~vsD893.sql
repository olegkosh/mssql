SELECT FORMAT(CreateDate, 'yyyy'), COUNT (*) as Error
  FROM [EDocRFM].[dbo].[Error]
  GROUP By FORMAT(CreateDate, 'yyyy')
  ORDER BY Error DESC

  --DELETE TOP(1) FROM [EDocRFM].[dbo].[Error]
  --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'

SELECT FORMAT(CreateDate, 'yyyy'), COUNT (*) as BankExtractIntegrationLog
  FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  GROUP By FORMAT(CreateDate, 'yyyy')
  ORDER BY BankExtractIntegrationLog DESC

  --DELETE TOP(1) FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'

--SELECT FORMAT(DtReg, 'yyyy'), COUNT (*) as OperationLog
--  FROM [WorkFlow].[Log].[OperationLog]
-- GROUP By FORMAT(DtReg, 'yyyy')
--  ORDER BY OperationLog DESC

  SELECT CONVERT(DATE, DtReg), COUNT (*) as OperationLog
  FROM [WorkFlow].[Log].[OperationLog]
 GROUP By CONVERT(DATE, DtReg)
  ORDER BY CONVERT(DATE, DtReg) DESC

  --DELETE TOP(1) FROM [WorkFlow].[Log].[OperationLog]
  --WHERE CONVERT(DATE, DtReg) > '2022-02-23'
