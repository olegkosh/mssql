
--USE EDocRFM --1,676 GB
--USE WorkGate --603 GB
--USE WorkFlow --236 GB
--USE WorkRepository --192 GB
--USE RFM --124 GB
--USE Messaging --75 GB
--USE WebPortalLocal


with pagesizeKB as (
	SELECT low / 1024 as PageSizeKB
	FROM master.dbo.spt_values
	WHERE number = 1 AND type = 'E'
)
,f_size as (
	select p.[object_id], 
		   sum([total_pages]) as TotalPageSize--,
		   --sum([used_pages])  as UsedPageSize--,
		   --sum([data_pages])  as DataPageSize
	from sys.partitions p  
	join sys.allocation_units a with (nolock) on p.partition_id = a.container_id
	left join sys.internal_tables it with (nolock) on p.object_id = it.object_id
	WHERE OBJECTPROPERTY(p.[object_id], N'IsUserTable') = 1
	group by p.[object_id]
)
,tbl as (
	SELECT
	  t.[schema_id],
	  t.[object_id],
	--  i1.rowcnt as CountRows,
	  (COALESCE(SUM(i1.reserved), 0) + COALESCE(SUM(i2.reserved), 0)) * (select top(1) PageSizeKB from pagesizeKB)/1024 as ReservedKB,
	  (COALESCE(SUM(i1.dpages), 0) + COALESCE(SUM(i2.used), 0)) * (select top(1) PageSizeKB from pagesizeKB)/1024 as DataKB,
	  ((COALESCE(SUM(i1.used), 0) + COALESCE(SUM(i2.used), 0))
	    - (COALESCE(SUM(i1.dpages), 0) + COALESCE(SUM(i2.used), 0))) * (select top(1) PageSizeKB from pagesizeKB)/1024 as IndexSizeKB,
	  ((COALESCE(SUM(i1.reserved), 0) + COALESCE(SUM(i2.reserved), 0))
	    - (COALESCE(SUM(i1.used), 0) + COALESCE(SUM(i2.used), 0))) * (select top(1) PageSizeKB from pagesizeKB)/1024 as UnusedKB
	FROM sys.tables as t with (nolock)
	LEFT OUTER JOIN sysindexes as i1 with (nolock) ON i1.id = t.[object_id] AND i1.indid < 2
	LEFT OUTER JOIN sysindexes as i2 with (nolock) ON i2.id = t.[object_id] AND i2.indid = 255
	WHERE OBJECTPROPERTY(t.[object_id], N'IsUserTable') = 1
	OR (OBJECTPROPERTY(t.[object_id], N'IsView') = 1 AND OBJECTPROPERTY(t.[object_id], N'IsIndexed') = 1)
	GROUP BY t.[schema_id], t.[object_id], i1.rowcnt
)


select * from (
SELECT
  --@@Servername AS Server,
  DB_NAME() AS DBName,
  SCHEMA_NAME(t.[schema_id]) as SchemaName,
  OBJECT_NAME(t.[object_id]) as TableName,
 -- t.CountRows as CountRows,
 -- t.ReservedKB as ReservedMb,
 -- t.DataKB as DataMb,
  --t.IndexSizeKB as IndexSizeMb ,
  --t.UnusedKB as UnusedMb,
 (f.TotalPageSize*(select top(1) PageSizeKB from pagesizeKB))/1024/1024 as TotalSizeGB--,
 --f.UsedPageSize*(select top(1) PageSizeKB from pagesizeKB) as UsedPageSizeMb--,
 --f.DataPageSize*(select top(1) PageSizeKB from pagesizeKB) as DataPageSizeMb
FROM f_size as f with (nolock)
inner join tbl as t with (nolock) on t.[object_id]=f.[object_id]) t
Where TotalSizeGb > 1
ORDER BY TotalSizeGB DESC
--order by 5 desc

 -- SELECT Year(CreateDate), COUNT (*) as Error
 -- FROM [EDocRFM].[dbo].[Error]
 -- GROUP By Year(CreateDate)
 -- ORDER BY Year(CreateDate) DESC

 -- --DELETE TOP(1) FROM [EDocRFM].[dbo].[Error]
 -- --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'


 -- SELECT Year(CreateDate), COUNT (*) as BankExtractIntegrationLog
 -- FROM [EDocRFM].[req].[BankExtractIntegrationLog]
 -- GROUP By Year(CreateDate)
 -- ORDER BY Year(CreateDate) DESC

 -- --DELETE TOP(1) FROM [EDocRFM].[req].[BankExtractIntegrationLog]
 -- --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'

 -- SELECT Year(DtReg), COUNT (*) as OperationLog
 -- FROM [WorkFlow].[Log].[OperationLog]
 --GROUP By Year(DtReg)
 -- ORDER BY Year(DtReg) DESC

 -- --DELETE TOP(1) FROM [WorkFlow].[Log].[OperationLog]
 -- --WHERE CONVERT(DATE, DtReg) > '2022-02-23'

  
 -- SELECT Year(OPERATION_DATE), COUNT (*) as Operation
 -- FROM [KSAND].[stat].[Operation]
 --GROUP By Year(OPERATION_DATE)
 --  ORDER BY Year(OPERATION_DATE) DESC
 --  --�������� �� 2012 ���

 -- --DELETE TOP(1) FROM [KSAND].[stat].[Operation]
 -- --WHERE CONVERT(DATE, OPERATION_DATE) > '2012-02-23'
	  
 -- SELECT Year(ChangeDate), COUNT (*) as LogChange
 --   FROM [KSAND].[ObjectLog].[LogChange]
 --GROUP By Year(ChangeDate)
 --  ORDER BY Year(ChangeDate) DESC
 --  --������ �� 2012 ����

 --  --begin transaction
 --  --DELETE TOP(1)  FROM [KSAND].[ObjectLog].[LogChange]
 --  --WHERE CONVERT(DATE, ChangeDate) > '2012-02-23'
 --  --rollback tran
   



	--   SELECT Year(CreateDate), COUNT (*) as Signs
 --     FROM [WebPortalLocal].[dbo].[Sign]
 --GROUP By Year(CreateDate)
 --  ORDER BY Year(CreateDate) DESC

 --  --begin transaction
 --  --DELETE TOP(1)   FROM [WebPortalLocal].[dbo].[Sign]
 --  --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
 --  --rollback transaction


  

	-- 	   SELECT Year(CreateDate), COUNT (*) as OperationLog_1
 --        FROM [WebPortalLocal].[ksoib].[OperationLog_1]
 --GROUP By Year(CreateDate)
 --  ORDER BY Year(CreateDate) DESC

 --  --begin transaction
 --  --DELETE TOP(1) FROM [WebPortalLocal].[ksoib].[OperationLog_1]
 --  --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
 --  --rollback transaction

 --  	 	   SELECT Year(CreateDate), COUNT (*) as OperationLog
 --        FROM [WebPortalLocal].[ksoib].[OperationLog]
 --GROUP By Year(CreateDate)
 --  ORDER BY Year(CreateDate) DESC

 --  --begin transaction
 --  --DELETE TOP(1) FROM [WebPortalLocal].[ksoib].[OperationLog]
 --  --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
 --  --rollback transaction


 --SELECT Year(CreateDate), COUNT (*) as PostMessage
 --FROM [Messaging].[dbo].[PostMessage]
 --GROUP By Year(CreateDate)
 --ORDER BY Year(CreateDate) DESC

 --  -- begin transaction
 --  --DELETE TOP(1)  FROM [Messaging].[dbo].[PostMessage]
 --  --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
 --  --rollback transaction

 --SELECT Year(CreateDate), COUNT (*) as PostMessageFile
 --FROM [Messaging].[dbo].[PostMessageFile] PMF
 --LEFT JOIN  [Messaging].[dbo].[PostMessage] PM 
 --ON PMF.IDPostMessageFile = PM.IDPostMessageFile
 --GROUP By Year(CreateDate)
 --ORDER BY Year(CreateDate) DESC

 ----  begin transaction
 ----  DELETE TOP(1) PMF 
 ----  FROM [Messaging].[dbo].[PostMessageFile] PMF
 ----LEFT JOIN  [Messaging].[dbo].[PostMessage] PM 
 ----ON PMF.IDPostMessageFile = PM.IDPostMessageFile
 ----  WHERE CONVERT(DATE, PM.CreateDate) > '2012-02-23'
 ----  rollback tran


