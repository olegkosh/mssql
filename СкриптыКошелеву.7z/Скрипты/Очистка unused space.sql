--select top 1 * from snapshots.active_sessions_and_requests
--60gb unused space
sp_spaceused 'snapshots.performance_counter_values'

alter table snapshots.performance_counter_values rebuild partition = all with (data_compression = page)
GO
alter table snapshots.os_wait_stats rebuild partition = all with (data_compression = page)
GO
alter table snapshots.notable_query_plan rebuild partition = all with (data_compression = page)
GO
alter table snapshots.os_memory_clerks rebuild partition = all with (data_compression = page)
GO
alter table snapshots.io_virtual_file_stats rebuild partition = all with (data_compression = page)
GO
alter table snapshots.active_sessions_and_requests rebuild partition = all with (data_compression = page)
GO

DBCC Cleantable (mdw, "snapshots.performance_counter_values", 0)
GO
sp_spaceused 'snapshots.performance_counter_values'



DBCC Cleantable (mdw, "snapshots.os_wait_stats", 0)
GO
DBCC Cleantable (mdw, "snapshots.notable_query_plan", 0)
GO
DBCC Cleantable (mdw, "snapshots.os_memory_clerks", 0)
GO
DBCC Cleantable (mdw, "snapshots.io_virtual_file_stats", 0)
GO
DBCC Cleantable (mdw, "snapshots.active_sessions_and_requests", 0)
GO

DROP INDEX CI_sysutility_ucp_smo_properties_internal ON sysutility_ucp_smo_properties_internal
Go
DROP INDEX IDX_trace_data_StartTime_EventClass ON trace_data 
GO
DROP INDEX IDX_os_wait_stats1 ON os_wait_stats 
GO
DROP INDEX IDX_snapshot_time_id ON snapshots_internal 
GO
DROP INDEX IDX_blocking_session_id ON active_sessions_and_requests 
GO
DROP INDEX IDX_collection_time ON active_sessions_and_requests 
GO
DROP INDEX IDX_performance_counter_instances1 ON performance_counter_instances 
GO