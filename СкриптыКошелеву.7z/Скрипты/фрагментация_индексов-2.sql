SELECT *
FROM sys.dm_db_index_physical_stats(DB_ID(),null, null, null, null)
WHERE avg_fragmentation_in_percent > 0
ORDER BY avg_fragmentation_in_percent
