SELECT TOP(10) * FROM [EDocRFM].[dbo].[Error] ORDER BY CreateDate DESC
SELECT Year(CreateDate), COUNT (*) as Error
  FROM [EDocRFM].[dbo].[Error]
  GROUP By Year(CreateDate)
  ORDER BY Year(CreateDate) DESC
  -- 21-22-23�.

  --DELETE TOP(1) FROM [EDocRFM].[dbo].[Error]
  --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'
SELECT TOP(10) * FROM [EDocRFM].[req].[BankExtractIntegrationLog]-- ORDER BY Year(CreateDate) DESC
SELECT Year(CreateDate), COUNT (*) as BankExtractIntegrationLog
  FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  GROUP By Year(CreateDate)
  ORDER BY Year(CreateDate) DESC
  --��� �� 21-22-23


  --DELETE TOP(1) FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  --WHERE CONVERT(DATE, CreateDate) > '2022-02-23'
  SELECT TOP(10) * FROM [WorkFlow].[Log].[OperationLog] ORDER BY Year(DtReg) DESC
  SELECT Year(DtReg), COUNT (*) as OperationLog
  FROM [WorkFlow].[Log].[OperationLog]
 GROUP By Year(DtReg)
  ORDER BY Year(DtReg) DESC
  -- � ������� ��������. ������ � ����� �������� � ������������

    SELECT Year(ExecutionDate), COUNT (*) as OperationMain
    FROM [WorkGate].[DataBus].[OperationMain]
  WHERE IsPositive = 1
 GROUP By Year(ExecutionDate)
  ORDER BY Year(ExecutionDate) DESC
  -- �������� 22-23 --�������� xml

      SELECT Year(OperateDate), COUNT (*) as IncomingHash
    FROM   [WorkGate].[XEDMS].[IncomingHash]
 GROUP By  Year(OperateDate)
  ORDER BY  Year(OperateDate) DESC
  -- �������� 22-23 ������� �������� fileimage


      SELECT Year(OperateDate), COUNT (*) as IncomingFile
     FROM [WorkGate].[XEDMS].[IncomingFile] I
	 LEFT JOIN [WorkGate].[XEDMS].[IncomingMessage] IM
	 ON IM.IDIncomingMessage = I.IDIncomingMessage
	  GROUP By  Year(OperateDate)
  ORDER BY  Year(OperateDate) DESC
    -- �������� 22-23 ������� �������� filebody

	      SELECT Year(CreateDate), COUNT (*) as ProcessMain
    FROM [WorkGate].[Logging].[ProcessMain]
	  GROUP By  Year(CreateDate)
  ORDER BY  Year(CreateDate) DESC
      -- �������� 22-23

	      SELECT Year(CreateDate), COUNT (*) as Image
		FROM [WorkData].[dbo].[Image]
	  GROUP By  Year(CreateDate)
  ORDER BY  Year(CreateDate) DESC

	
	 
  


--  --DELETE TOP(1) FROM [WorkFlow].[Log].[OperationLog]
--  --WHERE CONVERT(DATE, DtReg) > '2022-02-23'

--  SELECT TOP(10) *  FROM [KSAND].[stat].[Operation] ORDER BY Year(OPERATION_DATE) DESC
--  SELECT Year(OPERATION_DATE), COUNT (*) as Operation
--  FROM [KSAND].[stat].[Operation]
-- GROUP By Year(OPERATION_DATE)
--   ORDER BY Year(OPERATION_DATE) DESC
--   --�������� �� 2012 ���

--  --DELETE TOP(1) FROM [KSAND].[stat].[Operation]
--  --WHERE CONVERT(DATE, OPERATION_DATE) > '2012-02-23'
--SELECT TOP(10) *  FROM [KSAND].[ObjectLog].[LogChange] ORDER BY Year(ChangeDate) DESC
--  SELECT Year(ChangeDate), COUNT (*) as LogChange
--    FROM [KSAND].[ObjectLog].[LogChange]
-- GROUP By Year(ChangeDate)
--   ORDER BY Year(ChangeDate) DESC
--   --������ �� 2012 ����

--   --begin transaction
--   --DELETE TOP(1)  FROM [KSAND].[ObjectLog].[LogChange]
--   --WHERE CONVERT(DATE, ChangeDate) > '2012-02-23'
--   --rollback tran
   

-- SELECT TOP(10) * FROM [WebPortalLocal].[dbo].[Sign]
-- SELECT Year(CreateDate), COUNT (*) as Signs
-- FROM [WebPortalLocal].[dbo].[Sign]
-- GROUP By Year(CreateDate)
-- ORDER BY Year(CreateDate) DESC

--   --begin transaction
--   --DELETE TOP(1)   FROM [WebPortalLocal].[dbo].[Sign]
--   --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
--   --rollback transaction


  

--	 	   SELECT Year(CreateDate), COUNT (*) as OperationLog_1
--         FROM [WebPortalLocal].[ksoib].[OperationLog_1]
-- GROUP By Year(CreateDate)
--   ORDER BY Year(CreateDate) DESC

--   --begin transaction
--   --DELETE TOP(1) FROM [WebPortalLocal].[ksoib].[OperationLog_1]
--   --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
--   --rollback transaction

--   	 	   SELECT Year(CreateDate), COUNT (*) as OperationLog
--         FROM [WebPortalLocal].[ksoib].[OperationLog]
-- GROUP By Year(CreateDate)
--   ORDER BY Year(CreateDate) DESC

--   --begin transaction
--   --DELETE TOP(1) FROM [WebPortalLocal].[ksoib].[OperationLog]
--   --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
--   --rollback transaction


-- SELECT Year(CreateDate), COUNT (*) as PostMessage
-- FROM [Messaging].[dbo].[PostMessage]
-- GROUP By Year(CreateDate)
-- ORDER BY Year(CreateDate) DESC

--   -- begin transaction
--   --DELETE TOP(1)  FROM [Messaging].[dbo].[PostMessage]
--   --WHERE CONVERT(DATE, CreateDate) > '2012-02-23'
--   --rollback transaction

-- SELECT Year(CreateDate), COUNT (*) as PostMessageFile
-- FROM [Messaging].[dbo].[PostMessageFile] PMF
-- LEFT JOIN  [Messaging].[dbo].[PostMessage] PM 
-- ON PMF.IDPostMessageFile = PM.IDPostMessageFile
-- GROUP By Year(CreateDate)
-- ORDER BY Year(CreateDate) DESC

-- --  begin transaction
-- --  DELETE TOP(1) PMF 
-- --  FROM [Messaging].[dbo].[PostMessageFile] PMF
-- --LEFT JOIN  [Messaging].[dbo].[PostMessage] PM 
-- --ON PMF.IDPostMessageFile = PM.IDPostMessageFile
-- --  WHERE CONVERT(DATE, PM.CreateDate) > '2012-02-23'
-- --  rollback tran


