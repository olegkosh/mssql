SELECT TOP(10) * FROM [EDocRFM].[dbo].[Error] ORDER BY CreateDate DESC
SELECT Year(CreateDate), COUNT (*) as Error
  FROM [EDocRFM].[dbo].[Error]
  GROUP By Year(CreateDate)
  ORDER BY Year(CreateDate) DESC

  DELETE TOP(1000000) FROM [EDocRFM].[dbo].[Error]
  WHERE CONVERT(DATE, CreateDate) < '2021-01-01'
  SELECT COUNT(*) FROM [EDocRFM].[dbo].[Error]
  WHERE CONVERT(DATE, CreateDate) < '2021-01-01'

SELECT TOP(10) * FROM [EDocRFM].[req].[BankExtractIntegrationLog]-- ORDER BY Year(CreateDate) DESC
SELECT Year(CreateDate), COUNT (*) as BankExtractIntegrationLog
  FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  GROUP By Year(CreateDate)
  ORDER BY Year(CreateDate) DESC
  --��� �� 21-22-23


  DELETE TOP(100000) FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  WHERE CONVERT(DATE, CreateDate) < '2021-01-01'
  SELECT COUNT(*) FROM [EDocRFM].[req].[BankExtractIntegrationLog]
  WHERE CONVERT(DATE, CreateDate) < '2021-01-01'