declare @dbid int
select @dbid = db_id()
select (cast((user_seeks + user_scans + user_lookups) as float) / case user_updates when 0 then 1.0 else cast(user_updates as float) end) * 100 as [%]
    , (user_seeks + user_scans + user_lookups) AS total_usage
	--, (st.used_page_count) * 8 / 1024-- AS IndexSizeMB
    , objectname=object_name(s.object_id), s.object_id
    , indexname=i.name, i.index_id
    , user_seeks, user_scans, user_lookups, user_updates
    , last_user_seek, last_user_scan, last_user_update
    , last_system_seek, last_system_scan, last_system_update
    , 'DROP INDEX ' + i.name + ' ON ' + object_name(s.object_id) + ' GO' as [DROP]
	, 'ALTER INDEX ' + i.name + ' ON ' + s2.name + '.' + object_name(s.object_id) + ' REBUILD PARTITION = ALL WITH (SORT_IN_TEMPDB = ON, ONLINE = ON) GO' as [REBUILD], i.*
from sys.dm_db_index_usage_stats s,
    sys.indexes i
	JOIN sys.objects o with (nolock) ON o.[object_id] = i.[object_id]
    JOIN sys.schemas s2 with (nolock) ON o.[schema_id] = s2.[schema_id]
	--join sys.dm_db_partition_stats  st
	--ON st.[object_id] = i.[object_id] AND st.index_id = i.index_id
where database_id = @dbid 
and objectproperty(s.object_id,'IsUserTable') = 1
and i.object_id = s.object_id
and i.index_id = s.index_id
AND i.name IS NOT NULL
AND i.is_primary_key = 0        --��������� Primary Key
AND i.is_unique_constraint = 0  --��������� Constraints
--and object_name(s.object_id) = 'MyBigTable'
--AND user_seeks = 0
order by [%] asc
--order by user_updates desc
