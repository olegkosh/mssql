SELECT * FROM sys.dm_exec_requests
--WHERE session_id = '692';
Where status != 'background' and status != 'sleeping';
Go