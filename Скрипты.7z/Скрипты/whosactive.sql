sp_WhoIsActive @get_plans=1, @find_block_leaders=1, @get_full_inner_text = 1, @get_outer_command =1
,@sort_order = '[start_time] ASC'
--,@delta_interval = 5
--,@filter_type = 'program', @filter = 'PortalSignVerify'
--,@help = 1 

 
--select SizeInMB, DbName, WeekID,Date from [REPORT_DB].[dbo].[DBSizeDailyReport]--�������� ���������� ������ ��� ������
--ORDER BY SizeInMB desc, WeekID desc, DbName desc 
 

SELECT DbName, SizeInMB, min(WeekID) as [min], max(WeekID) as [max], COUNT(*)
from [REPORT_DB].[dbo].[DBSizeDailyReport]
WHERE DbName = 'Webportal'
GROUP BY DbName, SizeInMB
ORDER BY DbName desc, SizeInMB desc


-- SELECT * FROM webportal.dbo.TableSizeHistory   
-- where TotalSpaceMB > 100000
-- ORDER BY TotalSpaceMB desc, TableName desc
----DELETE TableSizeHistory WHERE TableName = '[srv].[TableStatistics]'

SELECT TableName, TotalSpaceMB, TotalSpaceMB / 1024 as TotalSpaceGB, min(DateTimeStamp) as [___�___], max(DateTimeStamp) as [___��___], COUNT(*) as [����] FROM webportal.dbo.TableSizeHistory
GROUP BY Tablename, TotalSpaceMB
ORDER BY TotalSpaceMB desc

--exec InsertDBSizeDailyReport
