 select s.session_id,login_name, login_time, program_name, status,last_request_start_time, last_request_end_time, original_login_name,database_id, connect_time, client_net_address, client_tcp_port,local_net_address,local_tcp_port
 from sys.dm_exec_sessions s
 left join sys.dm_exec_connections c
 on s.session_id = c.session_id
 where login_name like '%olen%'


 select * from sys.dm_exec_sessions s
 left join sys.dm_exec_connections c
 on s.session_id = c.session_id
 where host_name is not null
