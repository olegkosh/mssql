declare @dbid int
select @dbid = db_id()
select (cast((user_seeks + user_scans + user_lookups) as float) / case user_updates when 0 then 1.0 else cast(user_updates as float) end) * 100 as [%]
    , (user_seeks + user_scans + user_lookups) AS total_usage
    , objectname=object_name(s.object_id), s.object_id
    , indexname=i.name, i.index_id
    , user_seeks, user_scans, user_lookups, user_updates
    , last_user_seek, last_user_scan, last_user_update
    , last_system_seek, last_system_scan, last_system_update
    , 'DROP INDEX ' + i.name + ' ON ' + object_name(s.object_id) as [Command], i.*
from sys.dm_db_index_usage_stats s,
    sys.indexes i
where database_id = @dbid 
and objectproperty(s.object_id,'IsUserTable') = 1
and i.object_id = s.object_id
and i.index_id = s.index_id
AND i.name IS NOT NULL
AND i.is_primary_key = 0        --��������� Primary Key
AND i.is_unique_constraint = 0  --��������� Constraints
--and object_name(s.object_id) = 'MyBigTable'
order by [%] asc


SELECT
    i.name                  AS IndexName,
    SUM(s.used_page_count) * 8   AS IndexSizeKB,
	(SUM(s.used_page_count) * 8) / 1024 AS IndexSizeMb
FROM sys.dm_db_partition_stats  AS s
JOIN sys.indexes                AS i
ON s.[object_id] = i.[object_id] AND s.index_id = i.index_id
WHERE i.name in ('IX_LibrarySection_IdParentLibrarySection',
'IX_RequestCompany_IdCompany','IX_RequestCompany_IdRequestCompanyType','IX_FmTicketRaw_INN_KPP','IX_RequestCompanyAnswerFile_IdSign',
'IX_CryptoFile_CreateDate','IX_RequestCompanyAnswer_IdStatus','IX_RequestCompanyAnswerFile_IdRequestCompanyAnswer',
'IX_RequestCompanyAnswer_IdCompany','IX_DocumentImage_DocumentImageDate','IX_DocumentImage_CreateDate',
'IX_DocumentImage_DocumentImageNumber','FK_IdFormalizedMessage','IX_EventSubscriber_EventHandlerCode',
'IX_CalendarAction_IdCalendarActionType','IX_FmTicket_FmTicketDate','IX_CryptoMessage_IdCompany',
'IX_Operation_StartDate','IX_Operation_EndDate','IX_SupportPost_IdSupportPostCategory',
'IX_CertificateAuthority_Number','IX_LawProtectionResponses_DocumentDateOutgoing','IX_Spd_IDSpdStatus_CreateDate',
'IX_PostFile_IdPost','IX_RiskMarkerAvgPercentage_IdRiskMarkerTypeLevel','IX_Certificate_DateFrom','IX_Certificate_Thumbprint','IX_Certificate_DateTo','IX_MessageTypeActivityType_IdMessageType','IX_MessageTypeActivityType_ActivityTypeCode','IX_RiskMarkerType_IdRiskEstimationType','IX_ResponsiblePerson_IdPositionExperienceDocumentInfo','IX_ResponsiblePerson_IdHigherEducation','IX_ResponsiblePerson_IdKnowledgeIncreasingDocumentInfo','IDX_ImageFileContent_IdMessageType','IX_SpdTicket_CreateDate','IX_SpdTicket_IDXml','IX_CryptoCertificate_Thumbprint','IX_CryptoCertificate_IdCompany','IX_CalendarActionForcedSubscription_IdEventCalendarSubscriptionTime','IX_CompanyRegistry_IdCompany','IX_Director_IdKnowledgeIncreasingDocumentInfo','IX_Director_IdTrainingDocument','IX_FormalizedMessageError_IdFormalizedMessage','IX_MessageFileRegexCheking_GropName','IX_FormalizedMessage_IdFormalizedMessageTicket','IX_Document_DocumentDate','IX_FormalizedMessage_CreateDate','IX_FormalizedMessageTicket_CreateDate','idx_document_docnum_docdate_idsign','IX_EventSubscriberComplite_IdEvent','IX_Document_IdCompany','_dta_index_Sign_9_679673469__col__','idx_TerroristLog_TerroristLogDate_INCLUDE','idx_t_Sign-20210823-165222','IX_RiskEstimation_IdRiskEstimationType','IX_LawProtectionStatisticUni_IdLoadProcess','idx_File_FileLength_IDFile')
GROUP BY i.name
ORDER BY i.name
