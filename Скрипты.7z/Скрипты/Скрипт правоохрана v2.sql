USE WebPortal

SELECT
       C.CompanyName,
	   COUNT(*) AS numb
    --C.*,
    --PC.*
  FROM
  dbo.ProfileCard PC WITH(NOLOCK)
       INNER JOIN dbo.Company C WITH(NOLOCK) ON
             PC.IdCompany = C.IDCompany
		INNER JOIN [WebPortal].[dbo].[User] a 
ON C.IDCompany = a.IDCompany 
   LEFT OUTER JOIN dbo.ProfileCardComponentLinks PCCL WITH(NOLOCK) ON
             PC.IdProfileCardComponentLink = PCCL.IdProfileCardComponentLink
  WHERE
  PCCL.IdProfileCardComponentLink is not null --�� �����������
  AND
  C.CreateDate >= '2023-01-01' --����
  GROUP BY C.CompanyName--, C.CreateDate
  ORDER BY numb DESC