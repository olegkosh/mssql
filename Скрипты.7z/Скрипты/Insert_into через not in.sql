INSERT INTO [192.168.55.10].[Webportal].[dbo].[File]
  ([IDFile]
      ,[FileName]
      ,[FileExtension]
      ,[FileDate]
      ,[FileLength]
      ,[FileData]
      ,[CreateDate]
      ,[IdFileSign])

SELECT [IDFile]
      ,[FileName]
      ,[FileExtension]
      ,[FileDate]
      ,[FileLength]
      ,[FileData]
      ,[CreateDate]
      ,[IdFileSign]

  FROM Webportal3.dbo.[File]
 WHERE Webportal3.dbo.[File].IDFile NOT IN (SELECT IDFile
                       FROM [192.168.55.10].[Webportal].[dbo].[File]) AND CreateDate < '2016-10-10';