------��� ��������� �������� 

USE [WebPortal]
GO
SELECT
       C.CompanyName,
       PCCL.*,
	   PC.*
FROM
       dbo.ProfileCard PC WITH(NOLOCK)
       INNER JOIN dbo.ProfileCardComponentLinks PCCL WITH(NOLOCK) ON
             PC.IdProfileCardComponentLink = PCCL.IdProfileCardComponentLink
       INNER JOIN dbo.Company C WITH(NOLOCK) ON
             PC.IdCompany = C.IDCompany
	--WHERE C.IDCompany = 'DA59DFFF-AAAC-468C-91F1-CE607903137C'
		WHERE C.CreateDate >= '2023-01-01'

ORDER BY
       PCCL.CreateDate desc




--SELECT
--       C.CompanyName, 
--	   --C.*,
--	   PC.*
--  FROM
--  dbo.ProfileCard PC WITH(NOLOCK)
--       INNER JOIN dbo.Company C WITH(NOLOCK) ON
--             PC.IdCompany = C.IDCompany
--		 LEFT OUTER JOIN dbo.ProfileCardComponentLinks PCCL WITH(NOLOCK) ON
--             PC.IdProfileCardComponentLink = PCCL.IdProfileCardComponentLink

--		WHERE C.CompanyName EXISTS (SELECT t.[IDCompany],[CompanyName],[INN],[KPP],[OGRN]
--FROM [WebPortal].[dbo].[Company] t 
--INNER JOIN [WebPortal].[dbo].[User] a 
--ON t.IDCompany = a.IDCompany 
--INNER JOIN kb.dbo.Users_t s  
--ON a.IDUser = s.IDUserGuid 
--INNER JOIN [KB].[dbo].[UserMenu] x 
--ON s.IDUser=x.IDUser 
--WHERE x.[IDMenu] = 'cf0ad0ae-8c36-44f6-b37c-2d04b69d5c21') --���. ������������������ �����
----AND s.login NOT LIKE '%main%'
----AND s.ModifyDate >= '2022-11-29' --��������� ����������� ����, ���� �� ��������� ������������'

		
----	WHERE PC.IdProfileCardComponentLink is null AND C.CompanyName like '%���%';
----WHERE PC.IdProfileCardComponentLink is null


USE WebPortal

SELECT
       C.CompanyName, 
    --C.*,
    PC.*
  FROM
  dbo.ProfileCard PC WITH(NOLOCK)
       INNER JOIN dbo.Company C WITH(NOLOCK) ON
             PC.IdCompany = C.IDCompany
   LEFT OUTER JOIN dbo.ProfileCardComponentLinks PCCL WITH(NOLOCK) ON
             PC.IdProfileCardComponentLink = PCCL.IdProfileCardComponentLink
  WHERE 
  PCCL.IdProfileCardComponentLink is not null --�� �����������
  AND C.CompanyName IN (SELECT t.[CompanyName] FROM [WebPortal].[dbo].[Company] t 
INNER JOIN [WebPortal].[dbo].[User] a 
ON t.IDCompany = a.IDCompany 
INNER JOIN kb.dbo.Users_t s  
ON a.IDUser = s.IDUserGuid 
INNER JOIN [KB].[dbo].[UserMenu] x 
ON s.IDUser=x.IDUser 
WHERE x.[IDMenu] = 'cf0ad0ae-8c36-44f6-b37c-2d04b69d5c21'
--AND email like '%mvd.ru%'
)

ORDER BY CreateDate DESC