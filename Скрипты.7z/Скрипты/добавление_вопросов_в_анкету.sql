/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [IdExaminationAnswer]
      ,[IdExaminationQuestion]
      ,[ExaminationAnswerText]
      ,[IsRight]
      ,[OrderNumber]
      ,[IdRecStatus]
      ,[DisplayComment]
      ,[CheckingComment]
      ,[IdExaminationStandartCommentElement]
  FROM [WebSite].[dbo].[ExaminationAnswer]
  where IdExaminationQuestion = '2C15B1B1-5424-4A88-89F6-D53B6F08C3E1'

  /****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) qu.[IdExaminationQuestion]
      ,[IdExamination]
     -- ,[IdExaminationTopic]
     -- ,[IdExaminationAct]
      ,[ExaminationQuestionText]
	  ,an.ExaminationAnswerText
	  ,an.[IsRight] as IsRightAnswer
      ,an.[OrderNumber] as OrderNumberAnswer
      ,qu.[OrderNumber]
      ,qu.[IdRecStatus]
      ,[IdExaminationQuestionType]
      ,[IdExaminationStandartCommentSet]
      ,[ChangeUser]
      ,[ChangeDate]
      ,qu.[DisplayComment]
      ,qu.[CheckingComment]
      ,[CreateDate]
      ,[CreateUser1]
  FROM [WebSite].[dbo].[ExaminationQuestion] qu
  join [WebSite].[dbo].[ExaminationAnswer] an
  ON qu.IdExaminationQuestion = an.IdExaminationQuestion
  where ExaminationQuestionText like ('%������� �� �����%')

  select * from ExaminationQuestion  where ExaminationQuestionText like ('%���� �� ���������� � ����������������%')

 USE [WebSite]
GO

INSERT INTO [dbo].[ExaminationAnswer]

           (
		   --[IdExaminationAnswer]
           [IdExaminationQuestion]
           ,[ExaminationAnswerText]
           ,[IsRight]
           ,[OrderNumber]
           ,[IdRecStatus]          )
     VALUES
           (
		   --<IdExaminationAnswer, uniqueidentifier,>,
           '53FE7FEB-07C6-4406-BDF1-BE7099ECCDE4',
           '<p>���� ����������� �� ���������</p>'
		   ,
		   1,
           1,
           0
           )
GO






