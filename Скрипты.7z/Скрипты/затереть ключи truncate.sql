BEGIN TRANSACTION

select top 1 *
from [KB].[dbo].[OperationLog]
with (tablock, holdlock)


select top 1 *
from [KB].[dbo].[OperationLogParam]
with (tablock, holdlock)

ALTER TABLE dbo.OperationLogParam
 drop constraint FK_OperationLogParam_OperationLog

TRUNCATE TABLE [KB].[dbo].[OperationLogParam]
TRUNCATE TABLE [KB].[dbo].[OperationLog]

 
 ALTER TABLE dbo.OperationLogParam WITH CHECK
 add constraint FK_OperationLogParam_OperationLog FOREIGN KEY (IDOperationLog) references OperationLog (IdOperationLogGuid)
 ON DELETE CASCADE

 ALTER TABLE dbo.OperationLogParam CHECK CONSTRAINT FK_OperationLogParam_OperationLog

COMMIT
 
 SELECT * FROM [KB].[dbo].[OperationLog]